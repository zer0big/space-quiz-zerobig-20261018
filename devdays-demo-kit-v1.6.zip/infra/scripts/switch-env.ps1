<#
.SYNOPSIS
  [v1.4] 데모 구독(과 선택적으로 Azure DevOps 조직)을 바꾼다. 명령 하나로 설정 변경 → 배포 → 이름 반영 → 기준점 갱신 → 점검까지 수행한다.
.DESCRIPTION
  1. demo.config.json 의 subscriptionId(및 선택 값)를 바꾼다.
     -AdoOrganization/-AdoProject 를 주면 mcp.json 과 Git 원격(origin)도 새 조직 레포로 바꾼다.
     (새 조직에 프로젝트와 빈 레포를 미리 만들어 둔다. README 참고)
  2. setup-all.ps1 로 새 구독에 리소스 공급자 등록, Baseline, 알림(KST)을 배포한다.
  3. update-env-info.ps1 로 새 이름(Storage·Key Vault 등)을 Copilot 규칙과 DEMO-ENV.md 에 반영한다.
  4. 변경 파일을 커밋·푸시하고 baseline 태그를 새 커밋으로 옮긴다 (-NoGit 이면 생략).
  5. preflight.ps1 로 점검한다.
  이전 구독의 리소스는 지우지 않는다. 필요하면 cleanup-env.ps1 -SubscriptionId <이전 ID> 를 쓴다.
.EXAMPLE
  ./switch-env.ps1 -SubscriptionId <구독 ID>
.EXAMPLE
  ./switch-env.ps1 -SubscriptionId 3864b016-4594-40ad-a96b-4a08ac96b537 -AdoOrganization azure-mvp
#>
param(
    [Parameter(Mandatory = $true)][string]$SubscriptionId,
    [string]$Location,
    [string]$AdoOrganization,
    [string]$AdoProject,
    [string]$ConfluenceSpace,
    [switch]$NoGit
)
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot/_common.ps1"; $cfg = Get-DemoConfig
$root = Split-Path -Parent $PSScriptRoot

$before = $cfg.subscriptionId
$cfg.subscriptionId = $SubscriptionId
if ($Location) { $cfg.location = $Location }
if ($AdoOrganization) { $cfg.adoOrganization = $AdoOrganization }
if ($AdoProject) { $cfg.adoProject = $AdoProject }
if ($ConfluenceSpace) { $cfg.confluenceSpace = $ConfluenceSpace }
Save-DemoConfig $cfg
Write-Host "[1/4] 설정 변경: $before -> $SubscriptionId (ADO $($cfg.adoOrganization)/$($cfg.adoProject))"

# Git 원격을 설정의 ADO 레포로 맞춘다 (조직·프로젝트가 바뀐 경우)
$remoteUrl = "https://dev.azure.com/$($cfg.adoOrganization)/$($cfg.adoProject)/_git/$($cfg.adoRepo)"
$current = git -C $root remote get-url origin 2>$null
$remoteChanged = $current -and ($current -notmatch [regex]::Escape("dev.azure.com/$($cfg.adoOrganization)/$($cfg.adoProject)/_git/$($cfg.adoRepo)"))
if ($remoteChanged) {
    git -C $root remote set-url origin $remoteUrl
    Write-Host "      Git 원격 변경: $current -> $remoteUrl"
}

Write-Host '[2/4] 새 구독 준비 (setup-all)'
& "$PSScriptRoot/setup-all.ps1" -SkipPreflight

if (-not $NoGit) {
    Write-Host '[3/4] 기준점 갱신 (커밋·푸시·baseline 태그 이동)'
    Push-Location $root
    try {
        git add demo.config.json DEMO-ENV.md .github/copilot-instructions.md .vscode/mcp.json
        git commit -m "환경 전환: 구독 $SubscriptionId"
        git push -u origin main
        if ($LASTEXITCODE -ne 0) { throw "푸시 실패. 새 조직에 프로젝트 '$($cfg.adoProject)'와 빈 레포 '$($cfg.adoRepo)'가 있는지, 로그인 계정 권한을 확인한다." }
        git tag -f -a baseline -m "데모 시작 기준점 ($SubscriptionId)"
        git push -f origin baseline
    }
    finally { Pop-Location }
}
else { Write-Host '[3/4] -NoGit: 커밋 생략' }

Write-Host '[4/4] 점검'
& "$PSScriptRoot/preflight.ps1"
