<#
.SYNOPSIS
  [v1.3] 데모에서 쓰는 실제 리소스 이름을 출력한다.
.DESCRIPTION
  구독·리소스 그룹은 infra/demo.config.json 에서 읽는다.
  Storage Account·Key Vault 이름은 uniqueString(리소스 그룹 ID)으로 만들어지므로 구독이 바뀌면 이름도 바뀐다.
.EXAMPLE
  ./00-show-resources.ps1
#>
param([string]$SubscriptionId, [string]$ResourceGroup)
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot/_common.ps1"; $cfg = Get-DemoConfig
if (-not $SubscriptionId) { $SubscriptionId = $cfg.subscriptionId }
if (-not $ResourceGroup) { $ResourceGroup = $cfg.resourceGroup }

az account set --subscription $SubscriptionId
if ($LASTEXITCODE -ne 0) { throw '구독 전환 실패' }

$subName = az account show --query name -o tsv
Write-Host ''
Write-Host "구독        : $subName ($SubscriptionId)"
Write-Host "리소스 그룹 : $ResourceGroup"
Write-Host ''
az resource list -g $ResourceGroup --query '[].{Type:type, Name:name}' -o table
Write-Host ''
Write-Host '데모 단계 0에서 변경할 대상:'
Write-Host ("  1) NSG             : {0}" -f (az network nsg list -g $ResourceGroup --query '[0].name' -o tsv))
Write-Host ("  2) VNet            : {0}" -f (az network vnet list -g $ResourceGroup --query '[0].name' -o tsv))
Write-Host ("  3) Storage Account : {0}" -f (az storage account list -g $ResourceGroup --query '[0].name' -o tsv))
