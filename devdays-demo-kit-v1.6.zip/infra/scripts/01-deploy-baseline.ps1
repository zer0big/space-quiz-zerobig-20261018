<#
.SYNOPSIS
  [v1.3] 데모 워크로드 Baseline을 배포하고 what-if로 Drift가 없는지 확인한다.
.DESCRIPTION
  구독·리소스 그룹·지역은 infra/demo.config.json 에서 읽는다. 실패 시 중단한다.
.EXAMPLE
  ./01-deploy-baseline.ps1
#>
param([string]$SubscriptionId, [string]$ResourceGroup, [string]$Location)
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot/_common.ps1"; $cfg = Get-DemoConfig
if (-not $SubscriptionId) { $SubscriptionId = $cfg.subscriptionId }
if (-not $ResourceGroup) { $ResourceGroup = $cfg.resourceGroup }
if (-not $Location) { $Location = $cfg.location }
$root = Split-Path -Parent $PSScriptRoot

Write-Host "[0/3] 구독 고정: $SubscriptionId"
az account set --subscription $SubscriptionId
if ($LASTEXITCODE -ne 0) { throw '구독 전환 실패' }

Write-Host "[1/3] 리소스 그룹 생성: $ResourceGroup ($Location)"
az group create --name $ResourceGroup --location $Location --tags project=copilot-devdays environment=demo | Out-Null
if ($LASTEXITCODE -ne 0) { throw '리소스 그룹 생성 실패' }

Write-Host '[2/3] Baseline 배포'
az deployment group create `
    --resource-group $ResourceGroup `
    --name "baseline-$(Get-Date -Format yyyyMMddHHmm)" `
    --template-file "$root/bicep/main.bicep" `
    --parameters "$root/bicep/main.bicepparam" `
    --query 'properties.outputs' -o jsonc
if ($LASTEXITCODE -ne 0) { throw 'Baseline 배포 실패' }

Write-Host '[3/3] what-if 확인 (모든 리소스가 NoChange여야 정상)'
az deployment group what-if `
    --resource-group $ResourceGroup `
    --template-file "$root/bicep/main.bicep" `
    --parameters "$root/bicep/main.bicepparam"
