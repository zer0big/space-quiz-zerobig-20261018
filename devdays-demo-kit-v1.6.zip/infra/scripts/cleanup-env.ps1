<#
.SYNOPSIS
  [v1.3] 지정한 구독에서 데모 리소스 그룹 2개를 삭제한다 (이전 구독 정리용).
.DESCRIPTION
  확인 문구를 입력해야 실행된다. Key Vault는 소프트 삭제 상태로 남으며 -PurgeKeyVault 로 영구 삭제한다.
.EXAMPLE
  ./cleanup-env.ps1 -SubscriptionId <이전 구독 ID> -PurgeKeyVault
#>
param(
    [Parameter(Mandatory = $true)][string]$SubscriptionId,
    [switch]$PurgeKeyVault
)
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot/_common.ps1"; $cfg = Get-DemoConfig
if ($SubscriptionId -eq $cfg.subscriptionId) { Write-Warning '현재 데모 구독(demo.config.json)과 같은 구독이다.' }

az account set --subscription $SubscriptionId
if ($LASTEXITCODE -ne 0) { throw '구독 전환 실패' }
$kvs = az keyvault list -g $cfg.resourceGroup --query '[].name' -o tsv 2>$null

$answer = Read-Host "구독 $SubscriptionId 의 $($cfg.resourceGroup), $($cfg.opsResourceGroup) 를 삭제한다. 계속하려면 DELETE 입력"
if ($answer -ne 'DELETE') { Write-Host '취소했다.'; return }

az group delete -n $cfg.opsResourceGroup --yes 2>$null
az group delete -n $cfg.resourceGroup --yes
if ($PurgeKeyVault) { foreach ($k in $kvs) { az keyvault purge --name $k; Write-Host "Key Vault 영구 삭제: $k" } }
az account set --subscription $cfg.subscriptionId
Write-Host '완료. 현재 구독을 demo.config.json 의 구독으로 되돌렸다.'
