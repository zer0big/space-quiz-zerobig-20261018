<#
.SYNOPSIS
  [v1.3] 실시간 알림 구성(Event Grid 시스템 토픽 + Logic App -> Teams)을 배포한다.
.DESCRIPTION
  v1.3: 구독·리소스 그룹은 infra/demo.config.json 에서 읽는다.
  v1.2 변경 사항
  - Teams 카드 시각을 KST로 표시 (logicapp-workflow.json).
  - 웹후크 URL을 처음 한 번만 입력하면 현재 Windows 사용자 계정으로 암호화(DPAPI)해
    $HOME\.devdays\webhook.sec 에 저장하고, 다음 실행부터 재사용한다. -ResetWebhook 으로 다시 입력한다.
  v1.1 사항 유지
  - 웹후크 URL의 '&' 문자 문제를 피하려고 임시 매개변수 파일로 전달하고, 배포 후 삭제한다.
  - 배포가 실패하면 즉시 중단한다.
.EXAMPLE
  ./02-deploy-alerting.ps1
.EXAMPLE
  ./02-deploy-alerting.ps1 -ResetWebhook
#>
param(
    [string]$SubscriptionId,
    [string]$MonitoredResourceGroup,
    [string]$OpsResourceGroup,
    [string]$Location,
    [switch]$ResetWebhook
)
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot/_common.ps1"; $cfg = Get-DemoConfig
if (-not $SubscriptionId) { $SubscriptionId = $cfg.subscriptionId }
if (-not $MonitoredResourceGroup) { $MonitoredResourceGroup = $cfg.resourceGroup }
if (-not $OpsResourceGroup) { $OpsResourceGroup = $cfg.opsResourceGroup }
if (-not $Location) { $Location = $cfg.location }
$root = Split-Path -Parent $PSScriptRoot

Write-Host "[0/3] 구독 고정: $SubscriptionId"
az account set --subscription $SubscriptionId
if ($LASTEXITCODE -ne 0) { throw '구독 전환 실패' }

if ((az group exists --name $MonitoredResourceGroup) -ne 'true') {
    throw "감시 대상 리소스 그룹 '$MonitoredResourceGroup' 이(가) 이 구독에 없다. 01-deploy-baseline.ps1 을 먼저 실행한다."
}

# 웹후크 URL: 저장본이 있으면 재사용, 없으면 한 번 입력받아 암호화 저장
$secDir = Join-Path $HOME '.devdays'
$secFile = Join-Path $secDir 'webhook.sec'
if ($ResetWebhook -and (Test-Path $secFile)) { Remove-Item $secFile -Force }
if (Test-Path $secFile) {
    Write-Host "      저장된 웹후크 URL 사용 ($secFile)"
    $secure = Get-Content $secFile | ConvertTo-SecureString
}
else {
    $secure = Read-Host -Prompt 'Teams Workflows 웹후크 URL' -AsSecureString
    New-Item -ItemType Directory -Path $secDir -Force | Out-Null
    $secure | ConvertFrom-SecureString | Set-Content $secFile
    Write-Host "      웹후크 URL을 암호화해 저장했다 ($secFile)"
}
$webhookUrl = [System.Net.NetworkCredential]::new('', $secure).Password

Write-Host "[1/3] 운영 리소스 그룹 생성: $OpsResourceGroup"
az group create --name $OpsResourceGroup --location $Location --tags project=copilot-devdays purpose=demo-alerting | Out-Null
if ($LASTEXITCODE -ne 0) { throw '운영 리소스 그룹 생성 실패' }

$paramFile = Join-Path ([System.IO.Path]::GetTempPath()) ("alerting-params-{0}.json" -f [guid]::NewGuid())
$params = @{
    '$schema'      = 'https://schema.management.azure.com/schemas/2019-04-01/deploymentParameters.json#'
    contentVersion = '1.0.0.0'
    parameters     = @{
        monitoredResourceGroupName = @{ value = $MonitoredResourceGroup }
        teamsWebhookUrl            = @{ value = $webhookUrl }
    }
} | ConvertTo-Json -Depth 5
[System.IO.File]::WriteAllText($paramFile, $params, [System.Text.UTF8Encoding]::new($false))

try {
    Write-Host '[2/3] 알림 구성 배포 (Event Grid 구독 생성 시 Logic App이 검증 응답을 회신한다)'
    az deployment group create `
        --resource-group $OpsResourceGroup `
        --name "alerting-$(Get-Date -Format yyyyMMddHHmm)" `
        --template-file "$root/alerting/alerting.bicep" `
        --parameters "@$paramFile" `
        --query 'properties.outputs' -o jsonc
    if ($LASTEXITCODE -ne 0) { throw '알림 구성 배포 실패. 위 오류 메시지를 확인한다.' }
}
finally {
    Remove-Item -Path $paramFile -Force -ErrorAction SilentlyContinue
}

Write-Host '[3/3] 완료. 포털에서 리소스 태그를 하나 바꿔 Teams 카드의 시각(KST) 표시를 확인한다.'
