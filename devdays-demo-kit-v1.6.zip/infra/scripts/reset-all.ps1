<#
.SYNOPSIS
  [v1.6] 리허설이 끝난 뒤 데모 환경 전체를 처음 상태로 되돌린다 (명령 하나 또는 VS Code 작업 클릭 한 번).
.DESCRIPTION
  1. Azure      : 포털에서 바꾼 3건(RDP 규칙, snet-app-02 서브넷, Storage 태그)을 되돌린다.
  2. ADO 일감   : Drift 일감('drift' 태그 또는 제목에 Drift)을 휴지통으로 보낸다 (-CloseWorkItems: Done 처리).
  3. ADO PR     : infra 레포의 진행 중 PR 을 Abandon 한다.
  4. 레포       : main 을 baseline 태그로 되돌리고(force push) drift/* 브랜치를 지운다.
  5. Obsidian   : 리허설 주간 보고서를 지운다 (샘플 2026-W40.md 는 남긴다).
  6. Confluence : Atlassian API 토큰을 저장해 두었으면 상위 페이지와 하위 페이지를 삭제한다. 없으면 수동 안내.
  7. 점검       : preflight.ps1

  Azure DevOps 인증 순서: 저장된 PAT → az login 의 Entra 토큰. 둘 다 실패하면 Copilot 에게 붙여넣을 문장을 보여준다.
  최초 1회 저장:
    ./reset-all.ps1 -SetAdoPat              # Azure DevOps PAT (Work Items, Code: 읽기·쓰기)
    ./reset-all.ps1 -SetConfluenceToken     # Atlassian API 토큰 (+ demo.config.json 의 confluenceBaseUrl, confluenceEmail)
  저장값은 현재 Windows 사용자로 암호화해 $HOME\.devdays 에 둔다.
.EXAMPLE
  ./reset-all.ps1
#>
param(
    [switch]$Yes,
    [switch]$CloseWorkItems,
    [switch]$SetAdoPat,
    [switch]$SetConfluenceToken
)
$ErrorActionPreference = 'Continue'
. "$PSScriptRoot/_common.ps1"; $cfg = Get-DemoConfig
$root = Split-Path -Parent $PSScriptRoot          # infra
$kit = Split-Path -Parent $root                    # 키트 루트
$secDir = Join-Path $HOME '.devdays'
$adoPatFile = Join-Path $secDir 'ado-pat.sec'
$cfTokenFile = Join-Path $secDir 'confluence-token.sec'
$adoOrg = "https://dev.azure.com/$($cfg.adoOrganization)"
$adoBase = "$adoOrg/$([uri]::EscapeDataString($cfg.adoProject))"

function Save-Secret([string]$Path, [string]$Prompt) {
    New-Item -ItemType Directory -Path $secDir -Force | Out-Null
    Read-Host -Prompt $Prompt -AsSecureString | ConvertFrom-SecureString | Set-Content $Path
    Write-Host "저장했다: $Path"
}
function Read-Secret([string]$Path) {
    if (-not (Test-Path $Path)) { return $null }
    $sec = Get-Content $Path | ConvertTo-SecureString
    [System.Net.NetworkCredential]::new('', $sec).Password
}

if ($SetAdoPat) { Save-Secret $adoPatFile 'Azure DevOps PAT (Work Items·Code 읽기/쓰기)'; return }
if ($SetConfluenceToken) {
    if (-not $cfg.confluenceBaseUrl -or -not $cfg.confluenceEmail) {
        Write-Warning 'demo.config.json 에 confluenceBaseUrl(예: https://<사이트>.atlassian.net)과 confluenceEmail 을 먼저 적는다.'
    }
    Save-Secret $cfTokenFile 'Atlassian API 토큰'; return
}

$summary = [System.Collections.Generic.List[object]]::new()
function Add-Result([string]$Item, [string]$Result, [string]$Detail) { $summary.Add([pscustomobject]@{ 항목 = $Item; 결과 = $Result; 내용 = $Detail }) }

Write-Host '리허설 전체 초기화: Azure 변경 3건, ADO 일감·PR, 레포(baseline), Obsidian 보고서, Confluence 페이지를 되돌린다.'
if (-not $Yes) {
    $answer = Read-Host '계속하려면 RESET 입력'
    if ($answer -ne 'RESET') { Write-Host '취소했다.'; return }
}

# 1. Azure ---------------------------------------------------------------
Write-Host "`n[1/6] Azure 리소스 되돌리기"
& "$PSScriptRoot/04-reset-demo.ps1" -SkipPreflight
Add-Result 'Azure 변경 3건' '완료' 'RDP 규칙, snet-app-02, Storage 추가 태그'

# 2~3. Azure DevOps (REST) ----------------------------------------------
Write-Host "`n[2/6] Azure DevOps 일감·PR 정리 ($adoBase)"
$adoHeaders = $null; $adoAuth = ''
$pat = Read-Secret $adoPatFile
$candidates = @()
if ($pat) { $candidates += @{ name = '저장된 PAT'; h = @{ Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat")) } } }
$tok = az account get-access-token --resource 499b84ac-1321-427f-aa17-267ca6975798 --query accessToken -o tsv 2>$null
if ($tok) { $candidates += @{ name = 'az login 토큰'; h = @{ Authorization = "Bearer $tok" } } }
foreach ($c in $candidates) {
    try {
        $p = Invoke-RestMethod -Uri "$adoOrg/_apis/projects/$([uri]::EscapeDataString($cfg.adoProject))?api-version=7.1" -Headers $c.h -ErrorAction Stop
        if ($p.id) { $adoHeaders = $c.h; $adoAuth = $c.name; break }
    } catch { }
}
$copilotPrompt = "drift 태그가 붙은 열린 일감을 모두 Done으로 바꾸고, $($cfg.adoRepo) 레포의 진행 중 PR을 모두 Abandon해줘"
if (-not $adoHeaders) {
    Add-Result 'ADO 일감·PR' '수동' "인증 실패. Copilot Chat에 붙여넣기: `"$copilotPrompt`" (또는 ./reset-all.ps1 -SetAdoPat 후 재실행)"
}
else {
    # 일감
    try {
        $wiql = @{ query = "SELECT [System.Id] FROM workitems WHERE [System.TeamProject] = @project AND ([System.Tags] CONTAINS 'drift' OR [System.Title] CONTAINS 'Drift')" } | ConvertTo-Json
        $r = Invoke-RestMethod -Method Post -Uri "$adoBase/_apis/wit/wiql?api-version=7.1" -Headers $adoHeaders -ContentType 'application/json' -Body $wiql -ErrorAction Stop
        $ids = @($r.workItems | ForEach-Object { $_.id })
        foreach ($id in $ids) {
            if ($CloseWorkItems) {
                $patch = '[{"op":"add","path":"/fields/System.State","value":"Done"}]'
                Invoke-RestMethod -Method Patch -Uri "$adoBase/_apis/wit/workitems/$($id)?api-version=7.1" -Headers $adoHeaders -ContentType 'application/json-patch+json' -Body $patch | Out-Null
            }
            else { Invoke-RestMethod -Method Delete -Uri "$adoBase/_apis/wit/workitems/$($id)?api-version=7.1" -Headers $adoHeaders | Out-Null }
        }
        Add-Result 'ADO 일감' '완료' ("{0}건 {1} ({2})" -f $ids.Count, $(if ($CloseWorkItems) { 'Done 처리' } else { '휴지통 이동' }), $adoAuth)
    }
    catch { Add-Result 'ADO 일감' '수동' "오류: $($_.Exception.Message)" }
    # PR
    Write-Host "`n[3/6] Azure DevOps PR 정리"
    try {
        $prs = Invoke-RestMethod -Uri "$adoBase/_apis/git/repositories/$($cfg.adoRepo)/pullrequests?searchCriteria.status=active&api-version=7.1" -Headers $adoHeaders -ErrorAction Stop
        $prIds = @($prs.value | ForEach-Object { $_.pullRequestId })
        foreach ($p in $prIds) {
            Invoke-RestMethod -Method Patch -Uri "$adoBase/_apis/git/repositories/$($cfg.adoRepo)/pullrequests/$($p)?api-version=7.1" -Headers $adoHeaders -ContentType 'application/json' -Body '{"status":"abandoned"}' | Out-Null
        }
        Add-Result 'ADO PR' '완료' ("{0}건 Abandon" -f $prIds.Count)
    }
    catch { Add-Result 'ADO PR' '수동' "오류: $($_.Exception.Message)" }
}

# 4. 레포 ------------------------------------------------------------------
Write-Host "`n[4/6] 레포를 baseline 으로 되돌리기"
Push-Location $root
try {
    git fetch --all --tags --prune 2>$null
    git checkout -f main 2>$null
    git reset --hard baseline
    git push --force origin main 2>$null
    $pushOk = ($LASTEXITCODE -eq 0)
    $branches = @(git branch -r --list 'origin/drift/*' | ForEach-Object { $_.Trim() -replace '^origin/', '' })
    foreach ($b in $branches) { git push origin --delete $b 2>$null }
    git branch --list 'drift/*' | ForEach-Object { git branch -D $_.Trim() 2>$null }
    if ($pushOk) { Add-Result '레포' '완료' ("main = baseline, 원격 drift 브랜치 {0}개 삭제" -f $branches.Count) }
    else { Add-Result '레포' '확인' 'force push 거부: 레포 보안 설정에서 본인에게 Force push 허용' }
}
finally { Pop-Location }

# 5. Obsidian --------------------------------------------------------------
Write-Host "`n[5/6] Obsidian 주간 보고서 정리"
$weekly = Join-Path $kit 'DevDays-Vault/Reports/Weekly'
$removed = @()
if (Test-Path $weekly) {
    Get-ChildItem $weekly -Filter '*.md' | Where-Object { $_.Name -ne '2026-W40.md' } | ForEach-Object { Remove-Item $_.FullName -Force; $removed += $_.Name }
}
Add-Result 'Obsidian 보고서' '완료' $(if ($removed) { '삭제: ' + ($removed -join ', ') } else { '삭제할 파일 없음' })

# 6. Confluence ------------------------------------------------------------
Write-Host "`n[6/6] Confluence 페이지 정리"
$cfToken = Read-Secret $cfTokenFile
$manual = "스페이스 $($cfg.confluenceSpace)의 '$($cfg.confluenceParentPage)' 페이지 > ··· > 삭제(하위 페이지 포함) > 스페이스 휴지통에서 영구 삭제"
if (-not ($cfToken -and $cfg.confluenceBaseUrl -and $cfg.confluenceEmail)) {
    Add-Result 'Confluence' '수동' $manual
}
else {
    try {
        $base = $cfg.confluenceBaseUrl.TrimEnd('/')
        $h = @{ Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("$($cfg.confluenceEmail):$cfToken")); Accept = 'application/json' }
        $space = Invoke-RestMethod -Uri "$base/wiki/api/v2/spaces?keys=$([uri]::EscapeDataString($cfg.confluenceSpace))" -Headers $h -ErrorAction Stop
        $sid = $space.results[0].id
        $parent = Invoke-RestMethod -Uri "$base/wiki/api/v2/pages?space-id=$sid&title=$([uri]::EscapeDataString($cfg.confluenceParentPage))" -Headers $h -ErrorAction Stop
        if (-not $parent.results) { Add-Result 'Confluence' '완료' '삭제할 페이지 없음' }
        else {
            $pid0 = $parent.results[0].id
            $order = [System.Collections.Generic.List[string]]::new()
            function Collect([string]$id) {
                $kids = Invoke-RestMethod -Uri "$base/wiki/api/v2/pages/$id/children?limit=250" -Headers $h -ErrorAction Stop
                foreach ($k in $kids.results) { Collect $k.id }
                $order.Add($id)
            }
            Collect $pid0
            foreach ($id in $order) { Invoke-RestMethod -Method Delete -Uri "$base/wiki/api/v2/pages/$id" -Headers $h -ErrorAction Stop | Out-Null }
            foreach ($id in $order) { try { Invoke-RestMethod -Method Delete -Uri "$base/wiki/api/v2/pages/$($id)?purge=true" -Headers $h -ErrorAction Stop | Out-Null } catch { } }
            Add-Result 'Confluence' '완료' ("{0}개 페이지 삭제" -f $order.Count)
        }
    }
    catch { Add-Result 'Confluence' '수동' "API 오류($($_.Exception.Message)). $manual" }
}

Write-Host "`n=== 초기화 결과 ==="
$summary | Format-Table -Wrap | Out-String -Width 200 | Write-Host

Write-Host '=== 사전 점검 ==='
& "$PSScriptRoot/preflight.ps1"
Write-Host ''
Write-Host '다시 시작: VS Code 새 채팅(Agent 모드) → DEMO-GUIDE.md "다시 시작하기" 순서대로'
