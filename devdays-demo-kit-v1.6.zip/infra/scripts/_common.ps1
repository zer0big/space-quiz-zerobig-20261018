# [v1.3] 공통 함수. 모든 스크립트가 dot-source 한다.
# 환경 값의 원천은 infra/demo.config.json 하나이다. 구독을 바꿀 때는 switch-env.ps1 을 쓴다.

function Get-DemoConfigPath { Join-Path (Split-Path -Parent $PSScriptRoot) 'demo.config.json' }

function Get-DemoConfig {
    $path = Get-DemoConfigPath
    if (-not (Test-Path $path)) { throw "설정 파일이 없다: $path" }
    Get-Content $path -Raw -Encoding utf8 | ConvertFrom-Json
}

function Save-DemoConfig($cfg) {
    $json = $cfg | ConvertTo-Json -Depth 5
    [System.IO.File]::WriteAllText((Get-DemoConfigPath), $json + "`n", [System.Text.UTF8Encoding]::new($false))
}

function Write-Utf8File([string]$Path, [string]$Text) {
    [System.IO.File]::WriteAllText($Path, $Text, [System.Text.UTF8Encoding]::new($false))
}

function Get-KstNow { [DateTime]::UtcNow.AddHours(9) }
