<#
.SYNOPSIS
  [v1.5] 데모 환경을 한 번에 준비한다.
  로그인 → 확장·Bicep → 리소스 공급자 등록 → Baseline → 알림(KST) → 이름 반영 → 점검
.DESCRIPTION
  구독은 infra/demo.config.json 에서 읽는다. 이미 있는 구성은 건너뛰므로 여러 번 실행해도 된다.
  - 새 구독이면 Microsoft.Network/Storage/KeyVault/Logic/EventGrid 공급자를 등록한다.
  - Baseline: 리소스 그룹이 없거나 -RedeployBaseline 일 때만 배포
  - 알림: Logic App이 없거나, KST 정의가 아니거나, -RedeployAlerting 일 때만 배포
  - 마지막에 update-env-info.ps1 로 실제 이름을 Copilot 규칙·DEMO-ENV.md 에 반영한다.
.EXAMPLE
  ./setup-all.ps1
#>
param(
    [switch]$RedeployBaseline,
    [switch]$RedeployAlerting,
    [switch]$SkipPreflight
)
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot/_common.ps1"; $cfg = Get-DemoConfig
$sub = $cfg.subscriptionId
$sw = [System.Diagnostics.Stopwatch]::StartNew()

Write-Host "[1/7] Azure 로그인 확인 (구독 $sub)"
az account show -o none 2>$null
if ($LASTEXITCODE -ne 0) { az login -o none }
az account set --subscription $sub
if ($LASTEXITCODE -ne 0) { throw "구독 $sub 에 접근할 수 없다. az login 계정과 권한을 확인한다." }

Write-Host '[2/7] CLI 확장·Bicep 준비'
az extension show --name resource-graph -o none 2>$null
if ($LASTEXITCODE -ne 0) { az extension add --name resource-graph -o none }
az extension show --name azure-devops -o none 2>$null
if ($LASTEXITCODE -ne 0) { az extension add --name azure-devops -o none }   # reset-all.ps1 의 ADO 정리용
az bicep version 2>$null | Out-Null
if ($LASTEXITCODE -ne 0) { az bicep install }

Write-Host '[3/7] 리소스 공급자 등록 확인'
foreach ($ns in 'Microsoft.Network', 'Microsoft.Storage', 'Microsoft.KeyVault', 'Microsoft.Logic', 'Microsoft.EventGrid') {
    $state = az provider show --namespace $ns --query registrationState -o tsv 2>$null
    if ($state -ne 'Registered') {
        Write-Host "      $ns 등록 중..."
        az provider register --namespace $ns --wait -o none
    }
}

Write-Host '[4/7] Baseline'
if ($RedeployBaseline -or (az group exists -n $cfg.resourceGroup) -ne 'true') {
    & "$PSScriptRoot/01-deploy-baseline.ps1"
}
else { Write-Host '      이미 있음 (건너뜀). 다시 배포하려면 -RedeployBaseline' }

Write-Host '[5/7] 실시간 알림'
$la = "logic-$($cfg.prefix)-change-alert"
$def = az resource show -g $cfg.opsResourceGroup -n $la --resource-type Microsoft.Logic/workflows --query properties.definition -o json 2>$null
if ($RedeployAlerting -or -not ($def -match 'Korea Standard Time')) {
    & "$PSScriptRoot/02-deploy-alerting.ps1"
}
else { Write-Host '      이미 최신(KST) (건너뜀). 다시 배포하려면 -RedeployAlerting' }

Write-Host '[6/7] 실제 이름을 Copilot 규칙·DEMO-ENV.md 에 반영'
& "$PSScriptRoot/update-env-info.ps1"

if (-not $SkipPreflight) {
    Write-Host '[7/7] 사전 점검'
    & "$PSScriptRoot/preflight.ps1"
}
Write-Host ("총 소요: {0:mm\:ss}" -f $sw.Elapsed)
