<#
.SYNOPSIS
  Teams Workflows 웹후크로 테스트 Adaptive Card를 보낸다 (Logic App 배포 전 채널 연결 확인용).
#>
$ErrorActionPreference = 'Stop'
$secure = Read-Host -Prompt 'Teams Workflows 웹후크 URL' -AsSecureString
$url = [System.Net.NetworkCredential]::new('', $secure).Password

$card = @{
    type        = 'message'
    attachments = @(
        @{
            contentType = 'application/vnd.microsoft.card.adaptive'
            contentUrl  = $null
            content     = @{
                '$schema' = 'http://adaptivecards.io/schemas/adaptive-card.json'
                type      = 'AdaptiveCard'
                version   = '1.4'
                body      = @(
                    @{ type = 'TextBlock'; text = 'Azure 리소스 변경 감지 (테스트)'; weight = 'Bolder'; size = 'Medium' }
                    @{ type = 'FactSet'; facts = @(
                            @{ title = '이벤트'; value = 'ResourceWriteSuccess' }
                            @{ title = '대상'; value = 'Microsoft.Network/networkSecurityGroups/nsg-devdays-app' }
                        ) }
                )
            }
        }
    )
} | ConvertTo-Json -Depth 10

Invoke-RestMethod -Method Post -Uri $url -ContentType 'application/json; charset=utf-8' -Body ([System.Text.Encoding]::UTF8.GetBytes($card))
Write-Host '전송 완료. Teams 채널에서 카드를 확인한다.'
