<#
.SYNOPSIS
  [v1.3] 데모 단계 0의 수동 변경 3건을 CLI로 재현한다.
  (포털 시연이 어려울 때의 백업, 또는 세션 30분 전 사전 변경용)
.DESCRIPTION
  1) NSG  nsg-devdays-app 에 RDP(3389) 인바운드 허용 규칙 추가   -> 비인가 Drift (보안 영향)
  2) VNet vnet-devdays 에 서브넷 snet-app-02 추가                -> 승인된 설계 변경 (IaC 반영 대상)
  3) Storage Account (실행 시 실제 이름 출력) 에 태그 추가        -> 경미
  주의: CLI로 수행하면 변경 이력의 clientType이 Azure Portal이 아닌 CLI로 기록된다.
  v1.1: -SubscriptionId 필수, 대상 리소스 이름 출력.
.EXAMPLE
  ./03-demo-drift.ps1
#>
param(
    [string]$SubscriptionId,
    [string]$ResourceGroup,
    [string]$Prefix
)
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot/_common.ps1"; $cfg = Get-DemoConfig
if (-not $SubscriptionId) { $SubscriptionId = $cfg.subscriptionId }
if (-not $ResourceGroup) { $ResourceGroup = $cfg.resourceGroup }
if (-not $Prefix) { $Prefix = $cfg.prefix }

az account set --subscription $SubscriptionId
if ($LASTEXITCODE -ne 0) { throw '구독 전환 실패' }

$nsgName = "nsg-$Prefix-app"
$vnetName = "vnet-$Prefix"
$stName = az storage account list -g $ResourceGroup --query '[0].name' -o tsv
$stId = az storage account list -g $ResourceGroup --query '[0].id' -o tsv

Write-Host "[1/3] NSG '$nsgName' 에 RDP 허용 규칙 'Allow-RDP-Inbound' 추가"
az network nsg rule create `
    --resource-group $ResourceGroup --nsg-name $nsgName `
    --name 'Allow-RDP-Inbound' `
    --priority 300 --direction Inbound --access Allow --protocol Tcp `
    --source-address-prefixes '*' --source-port-ranges '*' `
    --destination-address-prefixes '*' --destination-port-ranges 3389 | Out-Null

Start-Sleep -Seconds 20

Write-Host "[2/3] VNet '$vnetName' 에 서브넷 'snet-app-02' (10.10.3.0/24) 추가"
$nsgId = az network nsg show -g $ResourceGroup -n $nsgName --query id -o tsv
az network vnet subnet create `
    --resource-group $ResourceGroup --vnet-name $vnetName `
    --name 'snet-app-02' --address-prefixes '10.10.3.0/24' `
    --network-security-group $nsgId | Out-Null

Start-Sleep -Seconds 20

Write-Host "[3/3] Storage Account '$stName' 에 태그 costCenter=demo-temp 추가"
az resource tag --ids $stId --tags costCenter=demo-temp --is-incremental | Out-Null

Write-Host '완료. 변경 이력은 Resource Graph에 반영되기까지 최대 5분 정도 걸릴 수 있다.'
