<#
.SYNOPSIS
  [v1.4.1] 세션 전 점검을 자동으로 수행하고 결과를 표로 보여준다 (T-30분 체크리스트 자동화).
.DESCRIPTION
  Azure 상태, 알림 구성, 레포 상태, 로컬 도구를 점검한다. 모든 항목이 OK면 데모를 시작할 수 있다.
  Azure 리소스를 변경하지 않는다 (조회와 what-if만 사용).
.EXAMPLE
  ./preflight.ps1
#>
$ErrorActionPreference = 'Continue'
. "$PSScriptRoot/_common.ps1"; $cfg = Get-DemoConfig
$SubscriptionId = $cfg.subscriptionId; $ResourceGroup = $cfg.resourceGroup
$OpsResourceGroup = $cfg.opsResourceGroup; $Prefix = $cfg.prefix
$root = Split-Path -Parent $PSScriptRoot
$results = [System.Collections.Generic.List[object]]::new()
function Add-Check([string]$Item, [bool]$Ok, [string]$Detail, [string]$Fix = '') {
    $results.Add([pscustomobject]@{ 결과 = $(if ($Ok) { 'OK' } else { 'FAIL' }); 항목 = $Item; 내용 = $Detail; 조치 = $(if ($Ok) { '' } else { $Fix }) })
}

Write-Host '점검 중... (what-if 포함 1~2분 소요)'

# 1. Azure 로그인·구독
az account set --subscription $SubscriptionId 2>$null
$cur = az account show --query id -o tsv 2>$null
Add-Check 'Azure 구독 (demo.config.json)' ($cur -eq $SubscriptionId) "$cur" 'az login 후 다시 실행'

# 2. CLI 확장·Bicep
$rg = az extension show --name resource-graph --query version -o tsv 2>$null
Add-Check 'resource-graph 확장' ([bool]$rg) "$rg" 'az extension add --name resource-graph'
$bicep = az bicep version 2>$null | Select-Object -First 1
Add-Check 'Bicep CLI' ($LASTEXITCODE -eq 0) "$bicep" 'az bicep install'

# 3. 리소스 그룹
$exists = (az group exists -n $ResourceGroup) -eq 'true'
Add-Check "리소스 그룹 $ResourceGroup" $exists '' './setup-all.ps1'

if ($exists) {
    # 4. 데모 변경 잔여물
    $nsg = "nsg-$Prefix-app"; $vnet = "vnet-$Prefix"
    $rdp = az network nsg rule list -g $ResourceGroup --nsg-name $nsg --query "[?name=='Allow-RDP-Inbound'].name" -o tsv
    Add-Check 'RDP 규칙 없음' (-not $rdp) "$nsg" './04-reset-demo.ps1'
    $sn = az network vnet subnet list -g $ResourceGroup --vnet-name $vnet --query "[?name=='snet-app-02'].name" -o tsv
    Add-Check 'snet-app-02 없음' (-not $sn) "$vnet" './04-reset-demo.ps1'
    $st = az storage account list -g $ResourceGroup --query '[0].name' -o tsv
    $tagNames = (az storage account show -g $ResourceGroup -n $st --query tags -o json | ConvertFrom-Json).PSObject.Properties.Name
    $extra = @($tagNames | Where-Object { $_ -notin 'project', 'managedBy', 'environment' })
    Add-Check 'Storage 추가 태그 없음' ($extra.Count -eq 0) ("$st " + ($extra -join ',')) './04-reset-demo.ps1'
    $inst = Get-Content "$root/.github/copilot-instructions.md" -Raw -Encoding utf8
    Add-Check 'Copilot 규칙의 환경 정보' ($inst -match [regex]::Escape($st) -and $inst -match [regex]::Escape($SubscriptionId)) '' './update-env-info.ps1 후 커밋, baseline 이동'

    # 5. what-if (Modify/Create/Delete 0건이어야 정상)
    $wi = az deployment group what-if -g $ResourceGroup -f "$root/bicep/main.bicep" -p "$root/bicep/main.bicepparam" --no-pretty-print -o json 2>$null | ConvertFrom-Json
    if ($wi) {
        $diff = @($wi.changes | Where-Object { $_.changeType -notin @('NoChange', 'Ignore') })
        Add-Check 'what-if 차이 0건' ($diff.Count -eq 0) ("차이 {0}건" -f $diff.Count) './04-reset-demo.ps1'
    }
    else { Add-Check 'what-if 실행' $false '실패' 'Bicep 경로와 로그인 상태 확인' }
}

# 6. 알림 구성 (Logic App 활성 + KST 정의)
$la = "logic-$Prefix-change-alert"
$state = az resource show -g $OpsResourceGroup -n $la --resource-type Microsoft.Logic/workflows --query properties.state -o tsv 2>$null
Add-Check "Logic App $la" ($state -eq 'Enabled') "$state" './02-deploy-alerting.ps1'
$def = az resource show -g $OpsResourceGroup -n $la --resource-type Microsoft.Logic/workflows --query properties.definition -o json 2>$null
Add-Check 'Teams 카드 KST 표시' ([bool]($def -match 'Korea Standard Time')) '' './02-deploy-alerting.ps1 (v1.2 재배포)'

# 7. 레포 상태 (main = baseline, 변경 없음)
Push-Location $root
try {
    $branch = git rev-parse --abbrev-ref HEAD 2>$null
    $head = git rev-parse HEAD 2>$null
    $base = git rev-parse 'baseline^{commit}' 2>$null
    $dirty = git status --porcelain 2>$null
    Add-Check '레포 브랜치 main' ($branch -eq 'main') "$branch" 'git checkout main'
    Add-Check '레포 = baseline' ($base -and $head -eq $base) '' './04-reset-demo.ps1 -ResetRepo'
    $origin = git remote get-url origin 2>$null
    Add-Check 'Git 원격 = 설정 ADO 레포' ([bool]($origin -match [regex]::Escape("dev.azure.com/$($cfg.adoOrganization)/$($cfg.adoProject)/_git/$($cfg.adoRepo)"))) "$origin" './switch-env.ps1 -SubscriptionId <ID>'
    Add-Check '작업 트리 깨끗함' (-not $dirty) '' 'git status 확인 후 커밋 또는 되돌리기'
}
finally { Pop-Location }

# 8. Copilot 구성 파일
foreach ($s in 'drift-check', 'weekly-report', 'confluence-publish') {
    Add-Check "Skill $s" (Test-Path "$root/.github/skills/$s/SKILL.md") '' '키트 파일 복사'
}

$results | Format-Table -Wrap | Out-String -Width 200 | Write-Host
$fail = @($results | Where-Object { $_.결과 -eq 'FAIL' }).Count
if ($fail -eq 0) { Write-Host '자동 점검 통과.' -ForegroundColor Green } else { Write-Host "FAIL $fail 건: '조치' 열을 실행한다." -ForegroundColor Yellow }
Write-Host ''
Write-Host '남은 수동 확인 (VS Code): 새 채팅 Agent 모드 / ADO·Confluence MCP 인증 확인 / 채팅에 / 입력 시 Skill 3종 표시'
