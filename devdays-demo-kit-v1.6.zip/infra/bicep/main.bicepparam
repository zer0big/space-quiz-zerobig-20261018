using 'main.bicep'

param prefix = 'devdays'

param tags = {
  project: 'copilot-devdays'
  managedBy: 'bicep'
  environment: 'demo'
}
