// =============================================================================
// GitHub Copilot Dev Days 데모 - 워크로드 Baseline
// 형상의 원천(Source of Truth). 이 파일과 실제 Azure 상태의 차이가 Drift이다.
// 배포 범위: 리소스 그룹 (기본 rg-devdays-demo)
// =============================================================================
targetScope = 'resourceGroup'

@description('배포 지역. 기본값은 리소스 그룹 지역이다.')
param location string = resourceGroup().location

@description('리소스 이름 접두사')
@minLength(3)
@maxLength(10)
param prefix string = 'devdays'

@description('공통 태그')
param tags object = {
  project: 'copilot-devdays'
  managedBy: 'bicep'
  environment: 'demo'
}

module network 'modules/network.bicep' = {
  name: 'network'
  params: {
    location: location
    prefix: prefix
    tags: tags
  }
}

module storage 'modules/storage.bicep' = {
  name: 'storage'
  params: {
    location: location
    tags: tags
  }
}

module keyVault 'modules/keyvault.bicep' = {
  name: 'keyvault'
  params: {
    location: location
    prefix: prefix
    tags: tags
  }
}

output vnetName string = network.outputs.vnetName
output nsgName string = network.outputs.nsgName
output storageAccountName string = storage.outputs.storageAccountName
output keyVaultName string = keyVault.outputs.keyVaultName
