// -----------------------------------------------------------------------------
// 네트워크: VNet 1개, 서브넷 2개, NSG 1개
// 서브넷은 VNet 안에 인라인으로 정의한다.
// 포털에서 서브넷을 추가하면 what-if가 VNet의 subnets 속성 변경으로 보고한다.
// -----------------------------------------------------------------------------
param location string
param prefix string
param tags object

var vnetName = 'vnet-${prefix}'
var nsgName = 'nsg-${prefix}-app'

resource nsg 'Microsoft.Network/networkSecurityGroups@2024-05-01' = {
  name: nsgName
  location: location
  tags: tags
  properties: {
    securityRules: [
      {
        name: 'Allow-HTTPS-From-VNet'
        properties: {
          description: 'VNet 내부에서의 HTTPS만 허용'
          priority: 100
          direction: 'Inbound'
          access: 'Allow'
          protocol: 'Tcp'
          sourceAddressPrefix: 'VirtualNetwork'
          sourcePortRange: '*'
          destinationAddressPrefix: 'VirtualNetwork'
          destinationPortRange: '443'
        }
      }
    ]
  }
}

resource vnet 'Microsoft.Network/virtualNetworks@2024-05-01' = {
  name: vnetName
  location: location
  tags: tags
  properties: {
    addressSpace: {
      addressPrefixes: [
        '10.10.0.0/16'
      ]
    }
    // 플랫폼 기본값을 명시해 what-if 노이즈("- privateEndpointVNetPolicies")를 제거한다 (v1.1)
    privateEndpointVNetPolicies: 'Disabled'
    subnets: [
      {
        name: 'snet-app-01'
        properties: {
          addressPrefix: '10.10.1.0/24'
          networkSecurityGroup: {
            id: nsg.id
          }
        }
      }
      {
        name: 'snet-data-01'
        properties: {
          addressPrefix: '10.10.2.0/24'
          networkSecurityGroup: {
            id: nsg.id
          }
        }
      }
    ]
  }
}

output vnetName string = vnet.name
output nsgName string = nsg.name
