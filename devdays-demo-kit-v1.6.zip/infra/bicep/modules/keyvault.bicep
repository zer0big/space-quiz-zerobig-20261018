// -----------------------------------------------------------------------------
// Key Vault (RBAC 권한 모델)
// 이름은 24자 제한: 'kv-' + prefix + '-' + uniqueString(13자)
// -----------------------------------------------------------------------------
param location string
param prefix string
param tags object

var keyVaultName = take('kv-${prefix}-${uniqueString(resourceGroup().id)}', 24)

resource keyVault 'Microsoft.KeyVault/vaults@2023-07-01' = {
  name: keyVaultName
  location: location
  tags: tags
  properties: {
    tenantId: subscription().tenantId
    sku: {
      family: 'A'
      name: 'standard'
    }
    enableRbacAuthorization: true
    enableSoftDelete: true
    softDeleteRetentionInDays: 7
    publicNetworkAccess: 'Enabled'
  }
}

output keyVaultName string = keyVault.name
