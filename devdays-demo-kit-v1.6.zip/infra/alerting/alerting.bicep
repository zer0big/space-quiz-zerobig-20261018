// =============================================================================
// 실시간 알림 전용 구성 (Copilot 데모의 범위 밖, 사전 구축)
// 흐름: 리소스 그룹 변경 -> Event Grid 시스템 토픽 -> Logic App -> Teams Workflows 웹후크
// 배포 범위: 운영 리소스 그룹 (기본 rg-devdays-ops)
// 시스템 토픽은 감시 대상 리소스 그룹(rg-devdays-demo)에 생성된다.
// =============================================================================
targetScope = 'resourceGroup'

@description('Logic App 배포 지역')
param location string = resourceGroup().location

@description('리소스 이름 접두사')
param prefix string = 'devdays'

@description('변경을 감시할 리소스 그룹 이름')
param monitoredResourceGroupName string = 'rg-devdays-demo'

@description('Teams Workflows "Send webhook alerts to a channel" 템플릿이 발급한 웹후크 URL')
@secure()
param teamsWebhookUrl string

param tags object = {
  project: 'copilot-devdays'
  managedBy: 'bicep'
  environment: 'demo'
  purpose: 'demo-alerting'
}

// Logic App (Consumption). 워크플로 정의는 JSON 파일에서 읽는다.
resource logicApp 'Microsoft.Logic/workflows@2019-05-01' = {
  name: 'logic-${prefix}-change-alert'
  location: location
  tags: tags
  properties: {
    state: 'Enabled'
    definition: loadJsonContent('logicapp-workflow.json')
    parameters: {
      teamsWebhookUrl: {
        value: teamsWebhookUrl
      }
    }
  }
}

// Event Grid 시스템 토픽과 구독은 감시 대상 리소스 그룹에 배포한다.
// 구독 생성 시 Event Grid가 검증 이벤트를 보내며, Logic App이 validationCode를 회신한다.
module eventGrid 'eventgrid.bicep' = {
  name: 'eventgrid-change-subscription'
  scope: resourceGroup(monitoredResourceGroupName)
  params: {
    prefix: prefix
    tags: tags
    endpointUrl: listCallbackUrl('${logicApp.id}/triggers/manual', '2019-05-01').value
  }
}

output logicAppName string = logicApp.name
output systemTopicName string = eventGrid.outputs.systemTopicName
