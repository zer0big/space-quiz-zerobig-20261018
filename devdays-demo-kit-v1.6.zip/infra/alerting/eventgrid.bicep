// -----------------------------------------------------------------------------
// 리소스 그룹 Event Grid 시스템 토픽 + Logic App 웹후크 구독
// - Write/Delete 성공 이벤트만 구독
// - 배포 기록(Microsoft.Resources/deployments)과 Event Grid 자체 변경은 제외
// - purpose=demo-alerting 태그: Copilot Skill이 Drift 판정에서 제외하는 기준
// -----------------------------------------------------------------------------
param prefix string
param tags object

@secure()
param endpointUrl string

resource systemTopic 'Microsoft.EventGrid/systemTopics@2022-06-15' = {
  name: 'evgt-${prefix}-rg-changes'
  location: 'global'
  tags: tags
  properties: {
    source: resourceGroup().id
    topicType: 'Microsoft.Resources.ResourceGroups'
  }
}

resource subscription 'Microsoft.EventGrid/systemTopics/eventSubscriptions@2022-06-15' = {
  parent: systemTopic
  name: 'to-logicapp-teams'
  properties: {
    destination: {
      endpointType: 'WebHook'
      properties: {
        endpointUrl: endpointUrl
        maxEventsPerBatch: 1
        preferredBatchSizeInKilobytes: 64
      }
    }
    eventDeliverySchema: 'EventGridSchema'
    filter: {
      includedEventTypes: [
        'Microsoft.Resources.ResourceWriteSuccess'
        'Microsoft.Resources.ResourceDeleteSuccess'
      ]
      advancedFilters: [
        {
          operatorType: 'StringNotBeginsWith'
          key: 'data.operationName'
          values: [
            'Microsoft.Resources/deployments'
            'Microsoft.EventGrid/'
          ]
        }
      ]
    }
    retryPolicy: {
      maxDeliveryAttempts: 5
      eventTimeToLiveInMinutes: 60
    }
  }
}

output systemTopicName string = systemTopic.name
