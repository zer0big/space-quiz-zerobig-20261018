# 네트워크 구성 (rg-devdays-demo)

이 문서는 `bicep/modules/network.bicep`과 일치해야 한다.

- 최종 갱신: 2026-10-07 (Baseline)

## VNet

| 항목 | 값 |
|---|---|
| 이름 | vnet-devdays |
| 주소 공간 | 10.10.0.0/16 |

## 서브넷

| 서브넷 | 주소 범위 | NSG | 용도 |
|---|---|---|---|
| snet-app-01 | 10.10.1.0/24 | nsg-devdays-app | 애플리케이션 계층 |
| snet-data-01 | 10.10.2.0/24 | nsg-devdays-app | 데이터 계층 |

예약 범위: 10.10.3.0/24 이후는 미할당이다.

## NSG 규칙 (nsg-devdays-app)

| 우선순위 | 이름 | 방향 | 동작 | 프로토콜 | 원본 | 대상 | 포트 |
|---|---|---|---|---|---|---|---|
| 100 | Allow-HTTPS-From-VNet | Inbound | Allow | TCP | VirtualNetwork | VirtualNetwork | 443 |

기본 규칙(65000 이후)은 Azure 기본값을 따른다.
