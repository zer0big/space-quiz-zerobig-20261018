# 서비스 흐름 (데모 가정)

데모용 가상 워크로드의 흐름이다. 실제 애플리케이션은 배포하지 않는다.

```mermaid
sequenceDiagram
  participant U as 내부 사용자 (VNet)
  participant A as 앱 (snet-app-01)
  participant K as Key Vault
  participant S as Storage Account
  U->>A: HTTPS 443 요청
  A->>K: 연결 비밀 조회 (Entra ID, RBAC)
  A->>S: 데이터 저장 (Entra ID, 공유 키 미사용)
  A-->>U: 응답
```

## 통제 포인트

| 구간 | 통제 | 근거 리소스 |
|---|---|---|
| 사용자 → 앱 | VNet 내부 HTTPS만 허용 | nsg-devdays-app 규칙 100 |
| 앱 → Key Vault | RBAC 권한 모델 | Key Vault enableRbacAuthorization |
| 앱 → Storage | 공유 키 접근 차단, TLS 1.2 이상 | Storage allowSharedKeyAccess=false |
