# 형상 변경 이력

새 변경은 표 맨 위에 추가한다. 형식은 `.github/copilot-instructions.md`를 따른다.

| 날짜(KST) | Issue 번호 | 변경 요약 | 변경 주체 | 처리 |
|---|---|---|---|---|
| 2026-10-07 | - | Baseline 배포 (VNet, NSG, Storage, Key Vault) | 배포 스크립트 | IaC 반영 완료 |
