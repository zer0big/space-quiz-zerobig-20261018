# 구성도 (rg-devdays-demo)

이 문서는 `bicep/` 정의와 일치해야 한다. Bicep 변경 시 함께 갱신한다.

- 기준: `bicep/main.bicep`
- 최종 갱신: 2026-10-07 (Baseline)

```mermaid
flowchart TB
  subgraph RG["리소스 그룹: rg-devdays-demo"]
    subgraph VNET["VNet: vnet-devdays (10.10.0.0/16)"]
      APP01["snet-app-01<br/>10.10.1.0/24"]
      DATA01["snet-data-01<br/>10.10.2.0/24"]
    end
    NSG["NSG: nsg-devdays-app<br/>Allow-HTTPS-From-VNet (443)"]
    ST["Storage Account<br/>st&lt;uniqueString&gt;"]
    KV["Key Vault<br/>kv-devdays-&lt;uniqueString&gt;"]
  end

  NSG -.연결.- APP01
  NSG -.연결.- DATA01
  APP01 -->|비밀 조회| KV
  APP01 -->|데이터 저장| ST
```

## 리소스 목록

| 리소스 | 이름 | 비고 |
|---|---|---|
| Virtual Network | vnet-devdays | 서브넷 2개, 인라인 정의 |
| Network Security Group | nsg-devdays-app | 두 서브넷에 연결 |
| Storage Account | st&lt;uniqueString&gt; | 공개 Blob 접근 차단, 공유 키 비활성화, TLS 1.2 |
| Key Vault | kv-devdays-&lt;uniqueString&gt; | RBAC 권한 모델, 소프트 삭제 7일 |

형상관리 제외 대상: `purpose=demo-alerting` 태그 리소스(알림용 Event Grid 시스템 토픽).
