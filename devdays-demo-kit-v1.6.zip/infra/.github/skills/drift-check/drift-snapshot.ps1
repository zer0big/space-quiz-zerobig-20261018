<#
.SYNOPSIS
  [v1.3] /drift-check 수집 스크립트. 변경 이력과 IaC 대조 결과를 압축된 표로 출력한다.
.DESCRIPTION
  - Resource Graph 변경 이력 조회와 Bicep what-if를 병렬로 실행한다.
  - 원본 JSON(수백 KB)을 Copilot에 넘기지 않고, 판정에 필요한 항목만 KST 시각과 함께 표로 줄인다.
  - 알림 구성(Event Grid 시스템 토픽)과 배포 기록은 제외하고, etag 같은 노이즈 속성은 걸러낸다.
  구독·리소스 그룹은 infra/demo.config.json 에서 읽는다. Azure 리소스를 변경하지 않는다.
.EXAMPLE
  pwsh -NoProfile -File .github/skills/drift-check/drift-snapshot.ps1 -Hours 1
#>
param([int]$Hours = 24)
$ErrorActionPreference = 'Continue'
$infra = (Resolve-Path "$PSScriptRoot/../../..").Path
$cfg = Get-Content "$infra/demo.config.json" -Raw -Encoding utf8 | ConvertFrom-Json
$sub = $cfg.subscriptionId; $rg = $cfg.resourceGroup
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

function Short($v, [int]$n = 90) {
    if ($null -eq $v) { return '-' }
    $s = if ($v -is [string]) { $v } else { $v | ConvertTo-Json -Compress -Depth 6 }
    if ($s.Length -gt $n) { $s.Substring(0, $n) + '…' } else { $s }
}
$noise = 'etag|provisioningState|resourceGuid|lastModified|changedTime|createdTime|systemData'

# 1) what-if 를 백그라운드로 시작 (가장 오래 걸리는 작업)
$wiJob = Start-ThreadJob -ScriptBlock {
    param($s, $g, $f, $p)
    az deployment group what-if --subscription $s -g $g -f $f -p $p --no-pretty-print -o json 2>$null
} -ArgumentList $sub, $rg, "$infra/bicep/main.bicep", "$infra/bicep/main.bicepparam"

# 2) Resource Graph 변경 이력 (그동안 실행)
$q = @"
resourcechanges
| where resourceGroup =~ '$rg'
| extend changeTime = todatetime(properties.changeAttributes.timestamp)
| where changeTime > ago(${Hours}h)
| extend type = tostring(properties.targetResourceType)
| where type !in~ ('microsoft.resources/deployments', 'microsoft.eventgrid/systemtopics')
| project kst = format_datetime(changeTime + 9h, 'yyyy-MM-dd HH:mm'),
          changeType = tostring(properties.changeType),
          id = tostring(properties.targetResourceId),
          changedBy = tostring(properties.changeAttributes.changedBy),
          clientType = tostring(properties.changeAttributes.clientType),
          changes = properties.changes
| order by kst desc
| limit 30
"@
$q = $q -replace '\s*\r?\n\s*', ' '   # az.cmd(Windows)는 여러 줄 인수를 자르므로 한 줄로 만든다
$arg = az graph query --subscriptions $sub --first 30 -q $q -o json 2>$null | ConvertFrom-Json

Write-Output "# Drift 수집 결과 (구독 $sub / $rg / 최근 ${Hours}시간, 시각 KST)"
Write-Output ''
Write-Output '## 1. 변경 이력 (Resource Graph)'
if (-not $arg -or $arg.count -eq 0) {
    Write-Output '변경 기록 없음. 변경 직후라면 반영까지 최대 5분이 걸릴 수 있으니 1~2분 뒤 다시 실행한다.'
}
else {
    Write-Output '| 시각 | 유형 | 리소스 | 변경 주체 | 클라이언트 | 변경 속성 (이전 → 현재) |'
    Write-Output '|---|---|---|---|---|---|'
    foreach ($r in $arg.data) {
        $props = @()
        if ($r.changes) {
            foreach ($p in $r.changes.PSObject.Properties) {
                if ($p.Name -match $noise) { continue }
                $props += "$($p.Name): $(Short $p.Value.previousValue 40) → $(Short $p.Value.newValue 40)"
                if ($props.Count -ge 5) { $props += '…'; break }
            }
        }
        $name = ($r.id -split '/')[-1]
        Write-Output ("| {0} | {1} | {2} | {3} | {4} | {5} |" -f $r.kst, $r.changeType, $name, $r.changedBy, $r.clientType, (($props -join '<br>') -replace '\|', '/'))
    }
}

# 3) what-if 결과 압축
$wiRaw = Receive-Job $wiJob -Wait -AutoRemoveJob
$wi = ($wiRaw -join "`n") | ConvertFrom-Json -ErrorAction SilentlyContinue
function Flatten($items, $prefix) {
    foreach ($d in $items) {
        $path = if ($prefix) { "$prefix.$($d.path)" } else { $d.path }
        if ($d.children) { Flatten $d.children $path }
        elseif ($path -notmatch $noise) {
            [pscustomobject]@{ path = $path; kind = $d.propertyChangeType; before = (Short $d.before 160); after = (Short $d.after 160) }
        }
    }
}
Write-Output ''
Write-Output '## 2. IaC 대조 (Bicep what-if)'
if (-not $wi) { Write-Output 'what-if 실행 실패. 로그인 상태와 Bicep 경로를 확인한다.' }
else {
    $diff = @($wi.changes | Where-Object { $_.changeType -ne 'NoChange' -and $_.resourceId -notmatch '(?i)systemTopics|deployments' })
    if ($diff.Count -eq 0) { Write-Output '차이 없음 (모든 리소스 NoChange).' }
    else {
        Write-Output '| 결과 | 리소스 | 속성 경로 | 변경 | 이전 | 현재 |'
        Write-Output '|---|---|---|---|---|---|'
        foreach ($c in $diff) {
            $name = ($c.resourceId -split '/')[-1]
            $rows = @(Flatten $c.delta '')
            if ($rows.Count -eq 0) { Write-Output ("| {0} | {1} | - | - | - | - |" -f $c.changeType, $name); continue }
            foreach ($x in ($rows | Select-Object -First 6)) {
                Write-Output ("| {0} | {1} | {2} | {3} | {4} | {5} |" -f $c.changeType, $name, $x.path, $x.kind, ($x.before -replace '\|', '/'), ($x.after -replace '\|', '/'))
            }
        }
    }
}
Write-Output ''
Write-Output '해석: what-if Modify/Delete = Bicep과 실제가 다름(Drift), Ignore = Bicep에 없는 리소스(미정의), 표에 없는 리소스 = 일치.'
