---
name: drift-check
description: Azure 리소스 그룹의 최근 변경 이력과 Bicep 정의를 대조해 형상 Drift를 판정하고 Azure DevOps 일감을 생성한다. 리소스 변경 점검, 형상 불일치 확인, 변경 일감 생성을 요청할 때 사용한다.
argument-hint: <리소스 그룹> <기간, 예: 최근 1시간>
disable-model-invocation: true
---

# 형상 Drift 점검 절차 (v1.6)

인수가 없으면 기간은 최근 24시간으로 한다. 구독·리소스 그룹은 `copilot-instructions.md`의 환경 정보를 따른다.
1~2단계는 확인을 묻지 않고 연속으로 수행한다. 승인은 3단계 일감 기록(G1) 한 지점에서만 받는다.

## 1. 수집 (명령 1회)

[drift-snapshot.ps1](./drift-snapshot.ps1)을 `infra` 폴더에서 실행한다. 기간은 시간 단위 정수로 넘긴다.
터미널 위치가 `infra`가 아니면 경로 앞에 `infra/`를 붙인다.

```powershell
pwsh -NoProfile -File .github/skills/drift-check/drift-snapshot.ps1 -Hours 1
```

- 변경 이력(Resource Graph)과 IaC 대조(what-if)를 병렬로 실행하고, 판정에 필요한 항목만 KST 표로 출력한다.
- 이 출력만 근거로 판정한다. `az graph query`나 `what-if`를 따로 다시 실행하지 않는다.
- "변경 기록 없음"이 나오면 1분 뒤 한 번만 다시 실행한다 (반영 지연 최대 5분).

## 2. 분류

| 분류 | 태그 | 판정 기준 | 심각도 |
|---|---|---|---|
| 비인가 Drift | unauthorized | what-if가 Modify/Delete를 보고하고, 변경 주체가 배포 파이프라인이 아니며, 사용자가 승인 변경이라고 알려주지 않음 | 보안 영향 시 높음, 그 외 보통 |
| IaC 미정의 리소스 | unmanaged | what-if가 Ignore로 보고한 리소스 | 보통 |
| 경미 | minor | 태그 등 운영 영향이 없는 속성만 변경 | 낮음 |

보안 영향 예: NSG 인바운드 허용 규칙 추가(특히 원본이 `*` 또는 `Internet`), 퍼블릭 네트워크 접근 허용, TLS 하향.
판정이 애매하면 단정하지 말고 "확인 필요"로 표시한다. 분류 결과를 아래 표 하나로 보여준다.

| 리소스 | 변경 내용 | 변경 주체 / 시각(KST) | 분류 | 심각도 | 권고 |
|---|---|---|---|---|---|

## 3. 일감 기록 (Azure DevOps MCP) · 승인 게이트 G1

분류 표를 보여준 직후, 확인 질문 없이 수행한다. 도구 승인 창이 승인 지점이다.

1. 열린 `drift` 태그 일감을 **한 번만** 검색한다. 같은 리소스 일감이 있으면 새로 만들지 않고 코멘트를 추가한다.
2. 없으면 작업 항목을 만든다. 유형·제목·태그 형식은 `copilot-instructions.md`를 따른다.
3. 설명 본문은 아래 **일감 본문 서식**(HTML)을 그대로 채워 넣는다. 일반 텍스트로 쓰지 않는다.

### 일감 본문 서식 (HTML)

```html
<h3>변경 요약</h3>
<table style="border-collapse:collapse;width:100%;font-size:14px">
<tr><th style="border:1px solid #c8c6c4;background:#f3f2f1;padding:6px 10px;text-align:left;width:25%">대상 리소스</th><td style="border:1px solid #c8c6c4;padding:6px 10px">{리소스 이름}</td></tr>
<tr><th style="border:1px solid #c8c6c4;background:#f3f2f1;padding:6px 10px;text-align:left">변경 시각 (KST)</th><td style="border:1px solid #c8c6c4;padding:6px 10px">{YYYY-MM-DD HH:mm}</td></tr>
<tr><th style="border:1px solid #c8c6c4;background:#f3f2f1;padding:6px 10px;text-align:left">변경 주체 / 클라이언트</th><td style="border:1px solid #c8c6c4;padding:6px 10px">{계정} / {Azure Portal 등}</td></tr>
<tr><th style="border:1px solid #c8c6c4;background:#f3f2f1;padding:6px 10px;text-align:left">분류 / 심각도</th><td style="border:1px solid #c8c6c4;padding:6px 10px"><b>{분류}</b> / {심각도}</td></tr>
</table>
<h3>변경 내용</h3>
<table style="border-collapse:collapse;width:100%;font-size:14px">
<tr><th style="border:1px solid #c8c6c4;background:#f3f2f1;padding:6px 10px;text-align:left">속성</th><th style="border:1px solid #c8c6c4;background:#f3f2f1;padding:6px 10px;text-align:left">이전</th><th style="border:1px solid #c8c6c4;background:#f3f2f1;padding:6px 10px;text-align:left">현재</th></tr>
<tr><td style="border:1px solid #c8c6c4;padding:6px 10px"><code>{속성 경로}</code></td><td style="border:1px solid #c8c6c4;padding:6px 10px">{이전 값}</td><td style="border:1px solid #c8c6c4;padding:6px 10px">{현재 값}</td></tr>
</table>
<h3>IaC 대조 (what-if)</h3>
<ul><li>{Modify / Ignore 등 결과 한 줄}</li></ul>
<h3>권고 조치</h3>
<ul><li>{원복 또는 IaC 반영(승인 시)}</li></ul>
```

코멘트(예: 원복 권고)도 같은 방식으로 `<h3>`, `<ul>`, 표를 써서 HTML로 남긴다.

## 4. 결과 보고

생성(또는 코멘트)한 일감 번호를 분류 표에 한 열로 추가해 한 번만 보여준다. 일감 번호는 환경 정보의 링크 형식으로 `[#번호](URL)` 링크를 건다.
Azure 리소스는 변경하지 않는다. 원복이나 IaC 반영은 사용자가 별도로 요청할 때만 진행한다.
