<#
.SYNOPSIS
  [v1.3] /weekly-report 수집 스크립트. 주차·파일 경로·7일 변경 통계·레포 이력을 압축된 표로 출력한다.
.DESCRIPTION
  - 주차(ISO, KST 기준), 보고서 경로, 지난주 보고서 존재 여부를 계산해 준다 (Copilot 계산 생략).
  - Resource Graph 7일 변경을 요약 통계와 주요 변경 15건으로 줄여 출력한다.
  - 로컬 git 이력(최근 7일, 모든 브랜치)을 출력한다.
  Azure DevOps 일감·PR 현황은 Skill 절차에 따라 MCP로 한 번씩만 조회한다.
.EXAMPLE
  pwsh -NoProfile -File .github/skills/weekly-report/weekly-snapshot.ps1
#>
$ErrorActionPreference = 'Continue'
$infra = (Resolve-Path "$PSScriptRoot/../../..").Path
$kit = Split-Path -Parent $infra
$cfg = Get-Content "$infra/demo.config.json" -Raw -Encoding utf8 | ConvertFrom-Json
$sub = $cfg.subscriptionId; $rg = $cfg.resourceGroup
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$kst = [DateTime]::UtcNow.AddHours(9)
$week = '{0}-W{1:00}' -f [System.Globalization.ISOWeek]::GetYear($kst), [System.Globalization.ISOWeek]::GetWeekOfYear($kst)
$prev = $kst.AddDays(-7)
$prevWeek = '{0}-W{1:00}' -f [System.Globalization.ISOWeek]::GetYear($prev), [System.Globalization.ISOWeek]::GetWeekOfYear($prev)
$vault = Join-Path $kit 'DevDays-Vault/Reports/Weekly'

Write-Output "# 주간 보고 수집 결과 ($rg, 기준 $($kst.ToString('yyyy-MM-dd HH:mm')) KST)"
Write-Output ''
Write-Output '| 항목 | 값 |'
Write-Output '|---|---|'
Write-Output "| 주차 | $week |"
Write-Output "| 보고서 경로 | DevDays-Vault/Reports/Weekly/$week.md (이미 있음: $(Test-Path "$vault/$week.md")) |"
Write-Output "| 지난주 보고서 | $prevWeek (있음: $(Test-Path "$vault/$prevWeek.md")) |"
Write-Output "| 기간 | $($kst.AddDays(-7).ToString('yyyy-MM-dd')) ~ $($kst.ToString('yyyy-MM-dd')) |"

$base = @"
resourcechanges
| where resourceGroup =~ '$rg'
| extend changeTime = todatetime(properties.changeAttributes.timestamp)
| where changeTime > ago(7d)
| extend type = tostring(properties.targetResourceType)
| where type !in~ ('microsoft.resources/deployments', 'microsoft.eventgrid/systemtopics')
"@
function OneLine([string]$t) { $t -replace '\s*\r?\n\s*', ' ' }   # az.cmd(Windows)는 여러 줄 인수를 자르므로 한 줄로 만든다
$stats = az graph query --subscriptions $sub -q (OneLine ($base + @"

| summarize cnt = count() by changeType = tostring(properties.changeType),
            changedBy = tostring(properties.changeAttributes.changedBy),
            clientType = tostring(properties.changeAttributes.clientType)
| order by cnt desc
"@)) -o json 2>$null | ConvertFrom-Json

$recent = az graph query --subscriptions $sub --first 15 -q (OneLine ($base + @"

| project kst = format_datetime(changeTime + 9h, 'yyyy-MM-dd HH:mm'), changeType = tostring(properties.changeType),
          id = tostring(properties.targetResourceId), changedBy = tostring(properties.changeAttributes.changedBy)
| order by kst desc
| limit 15
"@)) -o json 2>$null | ConvertFrom-Json

Write-Output ''
Write-Output '## 변경 통계 (최근 7일)'
if (-not $stats -or $stats.count -eq 0) { Write-Output '변경 없음 (또는 조회 실패).' }
else {
    Write-Output '| 변경 유형 | 변경 주체 | 클라이언트 | 건수 |'
    Write-Output '|---|---|---|---|'
    foreach ($r in $stats.data) { Write-Output ("| {0} | {1} | {2} | {3} |" -f $r.changeType, $r.changedBy, $r.clientType, $r.cnt) }
}

Write-Output ''
Write-Output '## 주요 변경 (최근 15건)'
if ($recent -and $recent.count -gt 0) {
    Write-Output '| 시각 | 유형 | 리소스 | 변경 주체 |'
    Write-Output '|---|---|---|---|'
    foreach ($r in $recent.data) { Write-Output ("| {0} | {1} | {2} | {3} |" -f $r.kst, $r.changeType, ($r.id -split '/')[-1], $r.changedBy) }
}

Write-Output ''
Write-Output '## 레포 이력 (최근 7일, 모든 브랜치)'
$log = git -C $infra log --all --since='7 days ago' --date=format:'%Y-%m-%d %H:%M' --pretty=format:'| %ad | %an | %s |' 2>$null
if ($log) { Write-Output '| 시각 | 작성자 | 커밋 |'; Write-Output '|---|---|---|'; $log | Select-Object -First 20 | ForEach-Object { Write-Output $_ } }
else { Write-Output '커밋 없음.' }
