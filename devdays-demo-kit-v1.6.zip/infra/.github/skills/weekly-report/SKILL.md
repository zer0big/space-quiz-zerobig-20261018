---
name: weekly-report
description: 한 주간의 Azure 형상 변경과 Drift 일감 처리 현황을 모아 주간 보고서를 Obsidian Vault에 게시한다. 주간 보고, 형상 현황 요약을 요청할 때 사용한다.
argument-hint: <리소스 그룹>
disable-model-invocation: true
---

# 주간 형상 보고서 작성 절차 (v1.6)

이 Skill에는 승인 게이트가 없다. 수집부터 Vault 파일 작성까지 확인을 묻지 않고 끝까지 수행한다.
구독·리소스 그룹은 `copilot-instructions.md`의 환경 정보를 따른다.

## 1. 수집 (명령 1회 + MCP 2회)

1. [weekly-snapshot.ps1](./weekly-snapshot.ps1)을 `infra` 폴더에서 실행한다. 터미널 위치가 `infra`가 아니면 경로 앞에 `infra/`를 붙인다.

```powershell
pwsh -NoProfile -File .github/skills/weekly-report/weekly-snapshot.ps1
```

   주차, 보고서 경로, 지난주 보고서 존재 여부, 7일 변경 통계, 주요 변경, 레포 이력이 표로 나온다.
   이 값을 그대로 쓰고 `az` 명령으로 다시 조회하지 않는다.

2. Azure DevOps MCP 조회는 두 번만 한다.
   - 일감: `drift` 태그 작업 항목을 한 번에 조회한다 (제목, 상태, 태그, 생성일, 변경일).
   - PR: `infra` 레포 PR 목록을 한 번 조회한다 (상태 전체, 최근 20건).

## 2. 보고서 작성

수집 결과의 "보고서 경로"에 파일을 만든다. 이미 있으면 묻지 않고 갱신하고, 결과 보고에 "갱신"이라고 적는다.

```markdown
---
date: <YYYY-MM-DD, KST>
week: <주차>
resource_group: <RG>
tags: [weekly-report, drift]
---

# <주차> 형상 변경 주간 보고

## 요약
(3문장 이내: 변경 건수, 비인가 Drift 건수, 미결 항목)

## 변경 통계
| 변경 유형 | 변경 주체 | 클라이언트 | 건수 |

## Drift 처리 현황
| 일감 | 분류 | 상태 | 연결 PR |

## 미결 항목
- [ ] ...

## 다음 주 조치
- ...

## 관련 노트
- 지난주: [[<지난주 주차>]]
- 구성도: [[architecture]]
```

## 3. 규칙

- 수치는 수집 결과에서만 가져오고 추정하지 않는다. 조회가 실패한 항목은 "조회 실패"로 적는다.
- 지난주 보고서가 "있음: False"이면 지난주 링크 줄을 생략한다.
- 시각은 `YYYY-MM-DD HH:mm (KST)`로, 리소스는 환경 정보 표의 실제 이름으로 표기한다.
- 보고서 안의 일감·PR은 환경 정보의 링크 형식으로 `[#번호](URL)`, `[PR #번호](URL)` 링크를 건다.
- 작성 후 파일 경로와 요약 3줄만 대화창에 보여준다.
- 마지막에 "팀·고객 공유가 필요하면 `/confluence-publish <주차>`로 Confluence에 게시할 수 있다"고 안내한다.
