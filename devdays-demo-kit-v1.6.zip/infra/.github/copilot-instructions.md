# 형상관리 운영 규칙 (v1.6)

이 레포는 Azure 리소스 그룹의 형상(Configuration)을 Bicep으로 관리한다.
Copilot은 아래 규칙을 모든 대화에서 따른다.

<!-- ENV:BEGIN -->
## 환경 정보 (자동 생성: scripts/update-env-info.ps1, 직접 수정하지 않는다)

이 표의 이름을 그대로 쓴다. 이름을 확인하려고 별도 조회하지 않는다.
모든 `az` 명령에는 `--subscription <구독 ID>`를 붙인다.

| 항목 | 값 |
|---|---|
| Azure 구독 | `setup-all.ps1` 실행 후 자동으로 채워진다 |
<!-- ENV:END -->

## 고정 정보

- 환경 값의 원천: `demo.config.json` (구독 변경은 `scripts/switch-env.ps1`)
- 형상 기준 파일: `bicep/main.bicep`, `bicep/main.bicepparam`
- 형상 일감 작업 항목 유형: `Issue` (Basic 프로세스)
- 주간 보고서 위치(Obsidian): 워크스페이스의 `DevDays-Vault/Reports/Weekly/`

## 원칙

- 대화 응답, 커밋 메시지, 작업 항목, 문서는 한국어로 작성한다.
- 모든 시각은 한국 표준시(KST, UTC+9)로 표기한다. 형식은 `YYYY-MM-DD HH:mm (KST)`이다.
- 형상의 원천은 `bicep/` 폴더이다. `docs/` 문서는 항상 Bicep과 일치해야 한다.
- Obsidian 노트와 Confluence 페이지는 `docs/`와 조회 결과를 원천으로 만든다. 원천에 없는 내용은 쓰지 않는다.
- 수치·사실은 조회 결과에서만 가져온다. 추정한 값은 쓰지 않는다.
- `purpose=demo-alerting` 태그가 붙은 리소스(알림용 Event Grid 시스템 토픽 등)는 Drift 판정과 문서에서 제외한다.

## 결과 보고 규칙 (가독성)

- 일감 번호, PR 번호, 브랜치, 수정한 파일, Confluence 페이지는 항상 **클릭 가능한 링크**로 쓴다. 형식은 환경 정보의 "링크 형식" 표를 따른다.
  - 예: `[#885](<일감 URL>)`, `[PR #12](<PR URL>)`, `[network.md](<파일 URL>)`
  - 파일 링크의 브랜치는 그 파일을 커밋한 브랜치다 (PR 전이면 drift 브랜치).
- 대화 결과는 표와 짧은 목록으로 보여주고, 긴 문단을 쓰지 않는다.

## 속도 규칙

- Skill에 수집 스크립트가 있으면 그 스크립트 출력만 사용한다. 같은 내용을 `az` 명령으로 다시 조회하지 않는다.
- 같은 종류의 조회·쓰기는 한 번에 모아서 호출한다 (예: 열린 Drift 일감 검색은 한 번).
- 중간 과정을 길게 설명하지 않는다. 결과 표와 다음 행동만 보여준다.

## 승인 정책

사람의 승인은 아래 세 지점에서만 받는다. 그 외 단계는 멈추거나 "진행할까요?"라고 묻지 않고 끝까지 수행한다.

| 게이트 | 대상 작업 | 승인 방식 |
|---|---|---|
| G1 일감 기록 | Azure DevOps 작업 항목 생성·코멘트 | 판정 표를 보여준 직후 도구를 호출한다. 도구 승인 창이 승인 지점이다 |
| G2 변경 제안 | `git push`, PR 생성·일감 연결 | 변경 파일 요약을 보여준 직후 실행한다. 도구 승인 창이 승인 지점이다 |
| G3 외부 공유 | Confluence 페이지 생성·업데이트 | 게시 계획 표를 보여준 직후 도구를 호출한다. 도구 승인 창이 승인 지점이다 |

- 대화에서 별도로 확인 질문을 하지 않는다. 승인 창 하나가 곧 승인이다.
- 변경이 승인된 것인지 반려할 것인지는 사람이 대화로 알려준다. 사람이 판정하지 않은 변경은 Bicep에 반영하지 않는다.
- 조회, `what-if`, 레포 안 파일 편집, 로컬 `git` 커밋, Vault 파일 작성은 승인 없이 진행한다.
- Azure 리소스를 생성·변경·삭제하는 명령(`az deployment group create`, `az resource delete`,
  `az network ... create/delete/update` 등)은 사용자가 명시적으로 요청하기 전에는 실행하지 않는다.

## 문서 갱신 규칙

- Bicep을 변경하면 다음 문서를 함께 갱신한다.
  - `docs/architecture.md`: Mermaid flowchart 구성도
  - `docs/network.md`: 서브넷·NSG 규칙 표
  - `docs/change-log.md`: 변경 이력 (표 맨 위에 한 행 추가)
- `change-log.md` 행 형식: `| 날짜(KST) | Issue 번호 | 변경 요약 | 변경 주체 | 처리 |`

## Azure DevOps 규칙

- 형상 변경 일감 제목 형식: `[Drift] <리소스명> <변경 요약>`
- 태그: `drift`, `rg-devdays-demo`, 분류(`unauthorized` / `unmanaged` / `minor` / `approved`)
- 새 일감을 만들기 전에 열린 `drift` 일감을 한 번 검색하고, 같은 리소스 일감이 있으면 코멘트만 추가한다.
- 브랜치 이름: `drift/<Issue 번호>-<짧은 설명>`
- PR은 관련 일감에 반드시 연결하고, PR 설명에 what-if 결과 요약을 넣는다.
- 일감 설명·코멘트는 HTML 서식으로 쓴다 (Azure DevOps 일감 본문은 HTML). 서식은 `drift-check` Skill의 "일감 본문 서식"을 따른다. 일반 텍스트 문단으로 쓰지 않는다.
- PR 설명은 Markdown 서식으로 쓴다: `## 변경 요약`(표) · `## what-if 결과`(표) · `## 관련 일감`(링크) · `## 수정 파일`(링크 목록).

## Confluence 규칙

- 환경 정보 표의 스페이스·상위 페이지 아래에만 페이지를 만든다.
- 같은 제목의 페이지가 있으면 새로 만들지 않고 업데이트한다.
