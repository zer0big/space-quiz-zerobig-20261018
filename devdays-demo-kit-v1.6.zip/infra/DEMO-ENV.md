# 데모 환경 실제 이름 (자동 생성)

`infra/scripts/switch-env.ps1` 또는 `setup-all.ps1`을 실행하면 이 파일이 실제 이름으로 채워진다.
