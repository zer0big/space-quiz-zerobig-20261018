---
tags: [infra, architecture]
source: infra/docs/architecture.md
---

# architecture

rg-devdays-demo 구성도의 Vault 측 요약 노트이다. 원본은 `infra/docs/architecture.md`이며, Bicep 변경 시 Copilot이 함께 갱신한다.

- VNet: vnet-devdays (10.10.0.0/16), 서브넷 snet-app-01, snet-data-01
- NSG: nsg-devdays-app (VNet 내부 HTTPS만 허용)
- Storage Account, Key Vault (RBAC)

관련: [[2026-W40]]
