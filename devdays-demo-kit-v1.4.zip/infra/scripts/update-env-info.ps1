<#
.SYNOPSIS
  [v1.3] 실제 리소스 이름을 조회해 Copilot 규칙·데모 문서·MCP 설정에 반영한다.
.DESCRIPTION
  다음 세 곳을 demo.config.json 과 실제 Azure 상태 기준으로 다시 쓴다.
  - .github/copilot-instructions.md 의 <!-- ENV:BEGIN --> ~ <!-- ENV:END --> 구간
    (Copilot이 이름을 매번 조회하지 않도록 실제 이름을 규칙에 넣어 둔다 = 응답 속도 개선)
  - DEMO-ENV.md (발표자용 실제 이름 표)
  - .vscode/mcp.json 의 Azure DevOps 조직 URL
  setup-all.ps1 과 switch-env.ps1 이 자동으로 호출한다. Baseline 상태에서 실행한다.
.EXAMPLE
  ./update-env-info.ps1
#>
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot/_common.ps1"; $cfg = Get-DemoConfig
$root = Split-Path -Parent $PSScriptRoot
$rg = $cfg.resourceGroup

az account set --subscription $cfg.subscriptionId
if ($LASTEXITCODE -ne 0) { throw '구독 전환 실패' }

$subName = az account show --query name -o tsv
$nsg  = az network nsg list -g $rg --query '[0].name' -o tsv
$vnet = az network vnet list -g $rg --query '[0].name' -o tsv
$st   = az storage account list -g $rg --query '[0].name' -o tsv
$kv   = az keyvault list -g $rg --query '[0].name' -o tsv

$table = @"
| 항목 | 값 |
|---|---|
| Azure 구독 | ``$subName`` (``$($cfg.subscriptionId)``) |
| 감시 대상 리소스 그룹 | ``$rg`` (알림용 ``$($cfg.opsResourceGroup)``, 지역 ``$($cfg.location)``) |
| NSG | ``$nsg`` |
| VNet | ``$vnet`` |
| Storage Account | ``$st`` |
| Key Vault | ``$kv`` |
| Azure DevOps | 조직 ``$($cfg.adoOrganization)``, 프로젝트 ``$($cfg.adoProject)``, 레포 ``$($cfg.adoRepo)`` (기본 브랜치 ``main``) |
| Confluence | 스페이스 ``$($cfg.confluenceSpace)``, 상위 페이지 ``$($cfg.confluenceParentPage)`` |
"@

# 1) copilot-instructions.md ENV 구간
$instPath = Join-Path $root '.github/copilot-instructions.md'
$inst = Get-Content $instPath -Raw -Encoding utf8
$block = "<!-- ENV:BEGIN -->`n## 환경 정보 (자동 생성: scripts/update-env-info.ps1, 직접 수정하지 않는다)`n`n이 표의 이름을 그대로 쓴다. 이름을 확인하려고 별도 조회하지 않는다.`n모든 ``az`` 명령에는 ``--subscription $($cfg.subscriptionId)``를 붙인다.`n`n$table`n<!-- ENV:END -->"
$pattern = '(?s)<!-- ENV:BEGIN -->.*?<!-- ENV:END -->'
if ($inst -notmatch $pattern) { throw 'copilot-instructions.md 에 ENV 구간 표식이 없다.' }
$inst = [regex]::Replace($inst, $pattern, [System.Text.RegularExpressions.MatchEvaluator] { param($m) $block })
Write-Utf8File $instPath $inst

# 2) DEMO-ENV.md
$envDoc = "# 데모 환경 실제 이름 (자동 생성)`n`n``scripts/update-env-info.ps1``이 만든 파일이다. 구독을 바꾸면 ``switch-env.ps1``이 다시 만든다.`n`n$table`n`n## 단계 0 변경 대상`n`n| # | 대상 | 변경 |`n|---|---|---|`n| 1 | NSG ``$nsg`` | 인바운드 규칙 ``Allow-RDP-Inbound`` (3389, 원본 Any, 우선순위 300) |`n| 2 | VNet ``$vnet`` | 서브넷 ``snet-app-02`` (``10.10.3.0/24``, NSG ``$nsg``) |`n| 3 | Storage Account ``$st`` | 태그 ``costCenter`` = ``demo-temp`` |`n"
Write-Utf8File (Join-Path $root 'DEMO-ENV.md') $envDoc

# 3) mcp.json ADO 조직 URL
$mcpPath = Join-Path $root '.vscode/mcp.json'
$mcp = Get-Content $mcpPath -Raw -Encoding utf8
$mcp = $mcp -replace 'https://mcp\.dev\.azure\.com/[^"]+', "https://mcp.dev.azure.com/$($cfg.adoOrganization)"
Write-Utf8File $mcpPath $mcp

Write-Host "환경 정보 반영 완료: NSG $nsg / VNet $vnet / Storage $st / Key Vault $kv"
