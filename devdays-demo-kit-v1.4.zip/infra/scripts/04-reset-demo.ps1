<#
.SYNOPSIS
  [v1.3] 리허설 후 데모 환경을 Baseline으로 되돌린다 (Azure + 선택적으로 레포).
.DESCRIPTION
  - Azure: 수동 변경 3건을 있으면 제거한다 (없으면 건너뜀).
  - -ResetRepo: 로컬 infra 레포를 baseline 태그로 되돌리고 main을 force push, 원격 drift/* 브랜치를 삭제한다.
    (데모 전용 레포에서만 사용한다. PR Abandon·Issue Close는 ADO에서 수동으로 한다.)
  - 마지막에 preflight.ps1 로 상태를 점검한다.
.EXAMPLE
  ./04-reset-demo.ps1
.EXAMPLE
  ./04-reset-demo.ps1 -ResetRepo
#>
param(
    [string]$SubscriptionId,
    [string]$ResourceGroup,
    [string]$Prefix,
    [switch]$ResetRepo
)
$ErrorActionPreference = 'Continue'
. "$PSScriptRoot/_common.ps1"; $cfg = Get-DemoConfig
if (-not $SubscriptionId) { $SubscriptionId = $cfg.subscriptionId }
if (-not $ResourceGroup) { $ResourceGroup = $cfg.resourceGroup }
if (-not $Prefix) { $Prefix = $cfg.prefix }
$root = Split-Path -Parent $PSScriptRoot

az account set --subscription $SubscriptionId
if ($LASTEXITCODE -ne 0) { throw '구독 전환 실패' }

$nsgName = "nsg-$Prefix-app"
$vnetName = "vnet-$Prefix"
$stName = az storage account list -g $ResourceGroup --query '[0].name' -o tsv
$stId = az storage account list -g $ResourceGroup --query '[0].id' -o tsv

Write-Host "[1/3] NSG '$nsgName' 의 RDP 규칙 'Allow-RDP-Inbound'"
$rule = az network nsg rule list -g $ResourceGroup --nsg-name $nsgName --query "[?name=='Allow-RDP-Inbound'].name" -o tsv
if ($rule) { az network nsg rule delete -g $ResourceGroup --nsg-name $nsgName -n 'Allow-RDP-Inbound'; Write-Host '      삭제' } else { Write-Host '      없음 (건너뜀)' }

Write-Host "[2/3] VNet '$vnetName' 의 서브넷 'snet-app-02'"
$subnet = az network vnet subnet list -g $ResourceGroup --vnet-name $vnetName --query "[?name=='snet-app-02'].name" -o tsv
if ($subnet) { az network vnet subnet delete -g $ResourceGroup --vnet-name $vnetName -n 'snet-app-02'; Write-Host '      삭제' } else { Write-Host '      없음 (건너뜀)' }

Write-Host "[3/3] Storage Account '$stName' 의 태그 costCenter"
$tag = az resource show --ids $stId --query 'tags.costCenter' -o tsv
if ($tag) { az resource update --ids $stId --remove tags.costCenter | Out-Null; Write-Host '      제거' } else { Write-Host '      없음 (건너뜀)' }

if ($ResetRepo) {
    Write-Host ''
    Write-Host '[레포] baseline 태그로 되돌린다'
    Push-Location $root
    try {
        git fetch --all --tags --prune
        git checkout main
        git reset --hard baseline
        git push --force origin main
        if ($LASTEXITCODE -ne 0) { Write-Warning 'force push 거부: 레포 보안 설정에서 본인에게 Force push 권한을 준다.' }
        $branches = git branch -r --list 'origin/drift/*' | ForEach-Object { $_.Trim() -replace '^origin/', '' }
        foreach ($b in $branches) { git push origin --delete $b; git branch -D $b 2>$null }
        Write-Host '      PR은 ADO에서 Abandon, Issue는 Closed로 정리한다.'
    }
    finally { Pop-Location }
}

Write-Host ''
& "$PSScriptRoot/preflight.ps1"
