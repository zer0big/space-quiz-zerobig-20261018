# 데모 진행 대본 v1.4 (45분: 개념 10분 + 데모 35분)

v1.2의 원칙은 "Copilot은 끝까지 일하고, 사람은 결정적인 순간에만 승인한다"이다.
조회·분석·문서 작성은 자동으로 진행되고, 승인 창은 아래 3개 게이트에서만 뜬다.

## 승인 게이트 (데모 전체에서 승인 창 약 5회)

| 게이트 | 언제 | 무엇을 승인하나 | 왜 사람이 결정하나 |
|---|---|---|---|
| G1 일감 기록 | 단계 1 끝, 단계 2 코멘트 | ADO Issue 생성·코멘트 | 조직의 공식 기록이 된다 |
| G2 변경 제안 | 단계 2 끝 | `git push`, PR 생성·일감 연결 | 형상 원천(IaC) 변경을 팀에 제안한다 |
| G3 외부 공유 | 단계 3-B | Confluence 게시 | 고객·팀이 보는 문서가 된다 |
| 차단 | 언제든 | Azure 배포·변경 명령 | 승인 창이 뜨면 거부한다 (통제 시연) |

자동 진행 대상: `az graph query`, `what-if`, Bicep·docs·Vault 파일 편집, 로컬 커밋.
설정 위치: `devdays.code-workspace`의 `chat.tools.terminal.autoApprove`, `chat.tools.edits.autoApprove`.

승인 창 조작 요령: 같은 도구가 여러 번 호출되는 게이트(G1의 Issue 3건, G3의 페이지 5개)에서는
첫 창에서 **이 세션에서 허용(Allow in this Session)**을 고른다. 나머지 호출은 이어서 진행된다.

## 환경 이름

구독·리소스 이름은 환경마다 달라진다(Storage Account·Key Vault는 구독별로 이름이 바뀐다).
실제 이름은 `infra/DEMO-ENV.md`를 본다. `setup-all.ps1`·`switch-env.ps1`이 자동으로 만들고,
같은 표가 `copilot-instructions.md`에도 들어가 Copilot이 이름을 따로 조회하지 않는다.

| 고정 이름 | 값 |
|---|---|
| 리소스 그룹 | `rg-devdays-demo` (알림용 `rg-devdays-ops`) |
| NSG / VNet | `nsg-devdays-app` / `vnet-devdays` |
| Azure DevOps | `azure-mvp` / `GHCPDevDays-Demo-IaC-Config-Mgmt` / 레포 `infra` |
| Confluence | 스페이스 `2026`, 상위 페이지 `rg-devdays-demo 형상관리` |
| 시각 표기 | KST |

## 구독 바꾸기 (리허설 → 발표 당일)

```powershell
cd <키트>\infra\scripts
./switch-env.ps1 -SubscriptionId <새 구독 ID> [-AdoOrganization <새 조직>]    # 설정 변경 → 배포 → 이름 반영 → 커밋·baseline 이동 → 점검 (약 10분)
./cleanup-env.ps1 -SubscriptionId <이전 구독 ID> -PurgeKeyVault   # 선택: 이전 구독 정리
```

## 응답 속도 운영 팁

| 원인 | v1.3 조치 | 발표자 행동 |
|---|---|---|
| Copilot이 `az` 명령을 여러 번 실행하고 대용량 JSON을 읽음 | 수집 스크립트 1회로 병렬 조회·압축(KST 표) | - |
| what-if 실행 시간(30~60초) | 변경 이력 조회와 병렬 실행 | 실행 중 해설 멘트로 채운다 |
| 리소스 이름 조회 | 이름을 규칙 파일에 미리 기록 | - |
| ADO·Confluence 개별 검색 반복 | 목록 조회 1회로 제한 | - |
| Resource Graph 반영 지연(최대 약 5분) | 기록 없으면 1분 뒤 1회만 재시도 | 단계 0 직후 개념 해설 1~2분을 두거나, T-30에 `03-demo-drift.ps1`로 사전 변경 |
| 대화가 길어질수록 응답 지연 | - | 단계 3-A부터는 **새 채팅**에서 실행 (Skill이 원천에서 다시 수집하므로 앞 대화가 필요 없다) |
| 모델 응답 속도 | - | 리허설에서 모델 선택기의 모델별 소요 시간을 비교해 빠른 모델로 고정 |

## 발표자 큐시트

승인 대기가 줄어든 만큼 각 단계에 "결과 해설" 시간을 배정했다.

| 시간 | 슬라이드 | 화면 | 할 일 | 승인 | 막히면 |
|---|---|---|---|---|---|
| 0:00–1:30 | 1–2 | 슬라이드 | 핵심 메시지 선언 | - | - |
| 1:30–10:00 | 3–9 | 슬라이드 | 문제 → Agent 모드 → MCP → Skill → 아키텍처 → 로드맵 | - | - |
| 10:00–13:00 | 10 단계 0 | 포털 → Teams | 수동 변경 3건, KST 알림 카드 확인 | - | 사전 변경분으로 진행 |
| 13:00–20:00 | 11 단계 1 | VS Code → Boards | `/drift-check` 후 자동 분석을 해설 | G1 x1 | 녹화본 1 |
| 20:00–29:00 | 12 단계 2 | VS Code → Repos | IaC·문서 현행화, PR, 배포 거부 연출 | G2 x2, G1 x1 | 완성본 브랜치 비교 |
| 29:00–33:00 | 13 단계 3-A | VS Code → Obsidian | `/weekly-report`, 그래프 뷰 | 없음 | 녹화본 3 |
| 33:00–38:00 | 14 단계 3-B | VS Code → Confluence | `/confluence-publish`, 페이지 트리 | G3 x1 | 녹화본 4 |
| 38:00–42:00 | 15 단계 4 | VS Code | Instructions·Skill 공개, 승인 설정 공개 | - | - |
| 42:00–45:00 | 16–17 | 슬라이드 | 인사이트, 내일 할 일 3가지 | - | - |

## 세션 전 준비 (T-30분, 약 5분)

```powershell
cd <infra 레포>\scripts
./04-reset-demo.ps1 -ResetRepo     # Azure·레포를 Baseline으로 되돌리고 preflight 자동 실행
```

preflight 표가 모두 OK이면 아래 3가지만 확인한다.

- [ ] VS Code: `devdays.code-workspace` 열기 → Copilot Chat **Agent** 모드 새 세션 → 채팅에 `/` 입력 시 Skill 3종 표시
- [ ] MCP 인증: `내 Azure DevOps 프로젝트 목록을 보여줘`, `Confluence 스페이스 2026의 페이지 목록을 보여줘` (승인 없이 바로 응답하면 정상)
- [ ] 창 준비: Teams 채널, Azure Portal(`nsg-devdays-app`), ADO Boards, Obsidian, Confluence 스페이스 `2026`

백업이 필요하면 `./03-demo-drift.ps1`로 사전 변경을 해 둔다. 이 경우 단계 0은 포털 화면만 보여준다.

## 단계 0. 상황 연출 (3분, 슬라이드 10)

포털에서 아래 3건을 순서대로 변경한다 (각 20초 간격).

| # | 대상 리소스 | 포털 경로 | 변경 내용 | 의도한 분류 |
|---|---|---|---|---|
| 1 | NSG `nsg-devdays-app` | 설정 > 인바운드 보안 규칙 > 추가 | 이름 `Allow-RDP-Inbound`, 포트 3389, 원본 Any, 우선순위 300 | 비인가 (보안 위험) |
| 2 | VNet `vnet-devdays` | 설정 > 서브넷 > + 서브넷 | 이름 `snet-app-02`, 범위 `10.10.3.0/24`, NSG `nsg-devdays-app` | 승인된 설계 변경 |
| 3 | Storage Account (`DEMO-ENV.md`의 이름) | 태그 | `costCenter` = `demo-temp` | 경미 |

Teams 채널에 카드 3장이 도착하고, 시각이 KST로 표시되는 것을 보여준다.

> 진행 멘트: "알림은 왔습니다. 진짜 일은 지금부터입니다. 누가, 무엇을, 왜 바꿨는지, IaC와 다른지, 문서는 누가 고칠지입니다."

## 단계 1. `/drift-check` (7분, 슬라이드 11)

```
/drift-check rg-devdays-demo 최근 1시간
```

| 흐름 | 화면 | 승인 |
|---|---|---|
| 수집 스크립트 1회 (변경 이력 + what-if 병렬) → 분류 | 명령 1개가 자동 실행되고 KST 표가 나온다 | 없음 (자동) |
| 분류 표 제시 | `Allow-RDP-Inbound` = 비인가(높음), `snet-app-02` = 비인가 또는 확인 필요, Storage Account 태그 = 경미 | - |
| Issue 3건 생성 | 승인 창 → **이 세션에서 허용** | G1 |

> 발표 포인트: 수집이 도는 동안 "Skill 폴더에 넣어 둔 수집 스크립트가 누가 바꿨는지와 IaC 차이를 동시에 모읍니다. 판단은 Copilot이 합니다"라고 해설한다. 승인 창이 뜨면 멈추고 "읽고 분석하는 건 맡기고, 조직의 기록을 남기는 순간에만 사람이 결정합니다"를 강조한다.

`snet-app-02`가 "비인가" 또는 "확인 필요"로 나오는 것이 정상이다. 승인 여부는 사람만 알기 때문이며, 단계 2에서 알려준다.

## 단계 2. 산출물 현행화 (9분, 슬라이드 12)

```
snet-app-02 서브넷 추가 일감은 승인된 설계 변경이야.
Bicep에 반영하고 구성도·네트워크 문서·변경 이력을 현행화한 뒤,
drift 브랜치로 커밋·푸시하고 PR을 만들어 해당 일감에 연결해줘. Azure 배포는 하지 마.
```

| 흐름 | 기대 결과 | 승인 |
|---|---|---|
| Bicep·문서 편집, what-if 재실행, 로컬 커밋 | `snet-app-02` 반영, `vnet-devdays` NoChange 수렴, docs 3종 갱신 | 없음 (자동) |
| `git push` | drift 브랜치 푸시 | G2 |
| PR 생성·일감 연결 | PR 설명에 what-if 요약 | G2 |

이어서:

```
Allow-RDP-Inbound 일감에는 원복 권고 코멘트만 남겨줘. 원복은 내가 직접 할게.
```

코멘트 승인 창(G1)을 승인한다. Copilot이 Azure 배포 명령을 제안하면 승인 창에서 거부해 통제를 시연한다.

> 발표 포인트: "파일 수정 수십 건은 자동이었고, 사람이 누른 건 푸시와 PR 두 번입니다. 되돌릴 수 없는 일만 사람이 합니다."

## 단계 3-A. `/weekly-report` → Obsidian (4분, 슬라이드 13)

새 채팅을 열고 실행한다.

```
/weekly-report rg-devdays-demo
```

승인 창 없이 끝까지 진행된다.

| 확인 포인트 | 기대 결과 |
|---|---|
| 파일 | `DevDays-Vault/Reports/Weekly/<주차>.md` (수집 스크립트가 KST 기준 주차를 계산. 10/18 발표 시 `2026-W42`) |
| 내용 | 변경 통계 표, Drift 처리 현황 표, 미결 항목(`Allow-RDP-Inbound` 원복) |
| Obsidian 시연 | ① 새 노트 열기 ② 백링크에서 `2026-W40`, `architecture` 연결 확인 ③ **그래프 뷰**(Ctrl+G) |

> 발표 포인트: "개인 Vault에 쓰는 일은 위험이 없으니 승인도 없습니다. 승인의 강도는 영향 범위에 비례합니다."

## 단계 3-B. `/confluence-publish` → Confluence (5분, 슬라이드 14)

```
/confluence-publish 2026-W42
```

| 흐름 | 기대 결과 | 승인 |
|---|---|---|
| 스페이스 `2026` 확인, 하위 페이지 목록 1회 조회, 게시 계획 표 | 상위 페이지 + 하위 4개의 생성/업데이트 여부 | 없음 (자동) |
| 게시 | 첫 승인 창에서 **이 세션에서 허용** → 나머지 연속 게시 | G3 |
| Confluence 화면 | 페이지 트리, 각 페이지 상단 "원천·갱신(KST)" 표기, Mermaid → 표 변환 | - |

> 발표 포인트: "같은 원천 문서를 개인용은 Obsidian에, 팀·고객 공유용은 Confluence에. 외부로 나가는 순간에만 승인합니다."

## 단계 4. 비밀 공개 (4분, 슬라이드 15)

1. `.github/copilot-instructions.md`의 **승인 정책** 표: "어디서 사람이 결정하는지도 문서로 정한다"
2. `.github/skills/drift-check/SKILL.md`: "이것은 코드가 아니라 업무 매뉴얼"
3. `.github/skills/drift-check/drift-snapshot.ps1`: "Skill에는 절차뿐 아니라 도구(스크립트)도 함께 넣을 수 있다"
4. `devdays.code-workspace`의 자동 승인 규칙: "조회는 true, 푸시와 Azure 변경은 false"
5. 대화창에 입력:

```
방금 승인된 서브넷 변경을 Bicep·문서·PR까지 처리한 과정을 재사용 가능한 Skill로 만들어줘.
```

> 마무리 멘트: "여러분의 업무 절차서가 곧 Copilot의 Skill이고, 승인 규칙이 곧 통제입니다."

## 리허설 초기화

```powershell
./04-reset-demo.ps1 -ResetRepo
```

Azure 변경 3건 제거, 레포를 `baseline`으로 되돌림(force push), 원격 `drift/*` 브랜치 삭제, preflight 점검까지 한 번에 수행한다.
PR은 ADO에서 Abandon, Issue는 Closed로 정리한다. Confluence 페이지는 남겨 두면 다음 실행 때 업데이트된다.

## 리허설 기록표

| 회차 | 단계 0 | 단계 1 | 단계 2 | 단계 3-A | 단계 3-B | 단계 4 | 승인 창 수 | 이슈 |
|---|---|---|---|---|---|---|---|---|
| 1 | | | | | | | | |
| 2 | | | | | | | | |

리허설에서 측정한 시간과 승인 창 수는 슬라이드 4(Before/After)의 수치로 사용한다.
