# CHANGELOG

## v1.5 (2026-10-17)

| 항목 | 내용 | 파일 |
|---|---|---|
| 대본 전면 개편 | 오프닝 장표 7장과 일치. 단계별 "Copilot이 일하는 동안 청중에게 할 말"(쉬운 표현)과 기술 설명(NOTE 상자)·발표자 메모(TIP 상자) 분리. 판단 1 + 승인 3 지점 표, Microsoft Learn MCP 30초 확장 시연, 예상 질문 | `DEMO-GUIDE.md` |
| 전체 초기화 | `reset-all.ps1` 하나로 Azure 변경 3건, ADO 일감(휴지통)·PR(Abandon), 레포(baseline, drift 브랜치), Obsidian 리허설 보고서 정리 + 점검. Confluence는 1분 수동 안내 | `scripts/reset-all.ps1`(신규), `scripts/04-reset-demo.ps1`(-SkipPreflight) |
| 다시 시작하기 | 5분 체크리스트 | `DEMO-GUIDE.md`, `README.md` |
| v1.4.1 통합 | Storage 태그를 키 대소문자와 무관하게 Bicep 기준으로 복원, 점검도 동일 기준 | `scripts/04-reset-demo.ps1`, `scripts/preflight.ps1` |
| 규칙 | 사람이 판정하지 않은 변경은 Bicep에 반영하지 않는다 | `.github/copilot-instructions.md` |
| Obsidian | 키트 루트 `.gitignore`에 `DevDays-Vault/.obsidian/` 추가 (점검 FAIL 방지) | `.gitignore`(신규) |
| 기타 | `azure-devops` CLI 확장 자동 설치, `confluenceBaseUrl` 설정(선택) | `scripts/setup-all.ps1`, `demo.config.json` |

## v1.4 (2026-10-17)

| 항목 | 내용 | 파일 |
|---|---|---|
| 발표 환경 반영 | 구독 `3864b016-4594-40ad-a96b-4a08ac96b537`, ADO 조직 `azure-mvp` | `infra/demo.config.json`, `infra/.vscode/mcp.json` |
| ADO 조직 전환 | `switch-env.ps1 -AdoOrganization/-AdoProject`: Git 원격(origin) 변경, 새 레포 첫 푸시·baseline 태그 | `scripts/switch-env.ps1` |
| 점검 | Git 원격이 설정의 ADO 레포와 같은지 확인 | `scripts/preflight.ps1` |
| 문서 | 새 조직 사전 준비(프로젝트·빈 레포·Entra 연결) 및 전환 절차 | `README.md`, `DEMO-GUIDE.md` |

## v1.3 (2026-10-15)

| 항목 | 내용 | 파일 |
|---|---|---|
| 구독 전환 | 환경 값을 `demo.config.json` 하나로 통합. `switch-env.ps1` 한 번으로 설정 변경·공급자 등록·배포·이름 반영·커밋·baseline 이동·점검. 이전 구독 정리 `cleanup-env.ps1` | `infra/demo.config.json`(신규), `scripts/_common.ps1`·`switch-env.ps1`·`update-env-info.ps1`·`cleanup-env.ps1`(신규), `scripts/*.ps1` |
| 실제 이름 자동 반영 | Storage·Key Vault 등 실제 이름을 `copilot-instructions.md` ENV 구간과 `DEMO-ENV.md`에 자동 기록 | `update-env-info.ps1`, `copilot-instructions.md`, `DEMO-ENV.md`(신규) |
| `/drift-check` 속도 | 수집 스크립트 1회로 대체: 변경 이력 + what-if 병렬 실행, 노이즈 제거, KST 압축 표 출력 | `skills/drift-check/drift-snapshot.ps1`(신규), `SKILL.md` |
| `/weekly-report` 속도 | 주차·경로·7일 통계·레포 이력을 수집 스크립트 1회로, ADO 조회는 2회로 제한 | `skills/weekly-report/weekly-snapshot.ps1`(신규), `SKILL.md` |
| `/confluence-publish` 속도 | 하위 페이지 목록 1회 조회 후 비교 | `skills/confluence-publish/SKILL.md` |
| 자동 승인 | 수집 스크립트 실행을 자동 승인 규칙에 추가 | `devdays.code-workspace`, `.vscode/copilot-approvals.user-settings.jsonc` |
| 새 구독 대응 | 리소스 공급자 자동 등록 | `scripts/setup-all.ps1` |
| 대본 | 환경 이름을 `DEMO-ENV.md` 참조로 변경, 구독 전환 절차·응답 속도 운영 팁 추가 | `DEMO-GUIDE.md`, `README.md` |

슬라이드는 변경하지 않았다.

## v1.2 (2026-10-09)

### 보완 (리허설 피드백)

| 항목 | 내용 | 파일 |
|---|---|---|
| `00-show-resources` 오류 | JMESPath 한글 키 오류(`invalid jmespath_type`) 수정: 키를 `Type`, `Name`으로 변경 | `scripts/00-show-resources.ps1` |
| KST 표기 | Teams 카드 시각을 KST로 변환(`convertFromUtc`, `Korea Standard Time`), 일감·문서·보고서 시각을 KST로 통일 | `alerting/logicapp-workflow.json`, `copilot-instructions.md`, Skill 3종, `docs/change-log.md` |
| 승인 과다 | 승인을 3개 게이트(G1 일감 기록, G2 push·PR, G3 Confluence 게시)로 한정. 조회·what-if·파일 편집·로컬 커밋은 자동 승인, Azure 변경 명령은 자동 승인 제외 | `devdays.code-workspace`, `.vscode/copilot-approvals.user-settings.jsonc`(신규), `copilot-instructions.md`, Skill 3종 |
| 준비 시간 | 원클릭 준비 `setup-all.ps1`, 자동 점검 `preflight.ps1` 추가. 웹후크 URL 암호화 저장·재사용. 초기화 `04-reset-demo.ps1 -ResetRepo`로 Azure·레포·점검 일괄 수행 | `scripts/setup-all.ps1`(신규), `scripts/preflight.ps1`(신규), `scripts/02-deploy-alerting.ps1`, `scripts/04-reset-demo.ps1` |
| 고정값 | 구독 `96fd96d0-9039-45c1-b1d9-979865cb7a2a`를 모든 스크립트 기본값·Instructions에 고정, Confluence 스페이스 `2026` 고정 | `scripts/*.ps1`, `copilot-instructions.md`, `confluence-publish/SKILL.md` |
| 대본 | 승인 게이트 표, 큐시트 재배분(해설 시간 확보), T-30 체크리스트를 preflight로 대체 | `DEMO-GUIDE.md`, `README.md` |

슬라이드는 변경하지 않았다.

## v1.1 (2026-10-09)

### 보완 (리허설 피드백)

| 항목 | 내용 | 파일 |
|---|---|---|
| 리소스 이름 누락 | 데모 대상 리소스를 실제 이름으로 명시 (예: Storage Account `st5oc7mt7vwxroy`), 이름 확인 스크립트 추가 | `DEMO-GUIDE.md`, `scripts/00-show-resources.ps1`(신규), `scripts/03-demo-drift.ps1`, `scripts/04-reset-demo.ps1` |
| 구독 혼동 | 모든 Azure 스크립트에 `-SubscriptionId` 필수화, 실패 시 중단 | `scripts/01`~`04` |
| 웹후크 URL `&` 오류 | URL을 임시 매개변수 파일로 전달 (`02-deploy-alerting.v1.1.ps1` 내용을 정식 파일에 통합) | `scripts/02-deploy-alerting.ps1` |
| what-if 노이즈 | VNet `privateEndpointVNetPolicies: 'Disabled'` 명시로 Baseline what-if를 NoChange로 정리 | `bicep/modules/network.bicep` |
| 조직 이름 | `tdg-zerobig` 반영, 일감 유형 `Issue`(Basic) 확정 | `.github/copilot-instructions.md`, `.vscode/mcp.json` |
| 터미널 도구 비활성 | 도구 선택기에서 터미널 실행 도구 활성화 절차 추가 | `README.md`, `DEMO-GUIDE.md` |

### 추가

| 항목 | 내용 | 파일 |
|---|---|---|
| Confluence 시나리오 | `/confluence-publish` Skill: docs·주간 보고서를 Confluence 페이지 트리로 게시·업데이트 | `.github/skills/confluence-publish/SKILL.md`(신규), `copilot-instructions.md` |
| 발표자 큐시트 | 시간·슬라이드·화면·백업 대응표, 리허설 초기화 절차 | `DEMO-GUIDE.md` |
| Obsidian 시연 구체화 | 백링크·그래프 뷰 시연 순서 | `DEMO-GUIDE.md` |

## v1.0 (2026-10-07)

최초 배포.
