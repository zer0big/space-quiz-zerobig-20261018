<#
.SYNOPSIS
  [v1.5] 리허설이 끝난 뒤 데모 환경 전체를 처음 상태로 되돌린다 (명령 하나).
.DESCRIPTION
  1. Azure     : 포털에서 바꾼 3건(RDP 규칙, snet-app-02 서브넷, Storage 태그)을 되돌린다.
  2. ADO 일감  : 데모에서 만든 Drift 일감('drift' 태그 또는 제목에 Drift)을 휴지통으로 보낸다
                 (-CloseWorkItems 를 주면 삭제 대신 Done 으로 닫는다).
  3. ADO PR    : infra 레포의 진행 중 PR 을 Abandon 한다.
  4. 레포      : main 을 baseline 태그로 되돌리고(force push) drift/* 브랜치를 지운다.
  5. Obsidian  : 리허설 때 만든 주간 보고서를 지운다 (샘플 2026-W40.md 는 남긴다).
  6. Confluence: 자동 삭제하지 않는다 (Atlassian MCP 에 삭제 기능이 없음). 화면에 1분 수동 절차를 보여준다.
  7. 점검      : preflight.ps1
  Azure DevOps 정리는 az login 계정으로 동작한다. 실패하면 해당 항목만 수동 절차를 보여주고 계속한다.
.EXAMPLE
  ./reset-all.ps1
.EXAMPLE
  ./reset-all.ps1 -Yes -CloseWorkItems
#>
param(
    [switch]$Yes,
    [switch]$CloseWorkItems
)
$ErrorActionPreference = 'Continue'
. "$PSScriptRoot/_common.ps1"; $cfg = Get-DemoConfig
$root = Split-Path -Parent $PSScriptRoot          # infra
$kit = Split-Path -Parent $root                    # 키트 루트
$org = "https://dev.azure.com/$($cfg.adoOrganization)"
$proj = $cfg.adoProject
$summary = [System.Collections.Generic.List[object]]::new()
function Add-Result([string]$Item, [string]$Result, [string]$Detail) { $summary.Add([pscustomobject]@{ 항목 = $Item; 결과 = $Result; 내용 = $Detail }) }

Write-Host '리허설 전체 초기화: Azure 변경 3건, ADO 일감·PR, 레포(baseline), Obsidian 보고서를 되돌린다.'
if (-not $Yes) {
    $answer = Read-Host '계속하려면 RESET 입력'
    if ($answer -ne 'RESET') { Write-Host '취소했다.'; return }
}

# 1. Azure
Write-Host "`n[1/6] Azure 리소스 되돌리기"
& "$PSScriptRoot/04-reset-demo.ps1" -SkipPreflight
Add-Result 'Azure 변경 3건' '완료' 'RDP 규칙, snet-app-02, Storage 추가 태그'

# 2. ADO 일감
Write-Host "`n[2/6] Azure DevOps 일감 정리 ($org / $proj)"
$wiql = "SELECT [System.Id] FROM workitems WHERE [System.TeamProject] = @project AND ([System.Tags] CONTAINS 'drift' OR [System.Title] CONTAINS 'Drift')"
$items = az boards query --wiql $wiql --org $org --project $proj -o json 2>$null | ConvertFrom-Json
if ($LASTEXITCODE -ne 0) {
    Add-Result 'ADO 일감' '수동' "Boards 에서 [Drift] 일감을 삭제한다 (az login 계정이 $($cfg.adoOrganization) 조직과 다른 테넌트일 수 있음)"
}
else {
    $ids = @($items | ForEach-Object { $_.id })
    foreach ($id in $ids) {
        if ($CloseWorkItems) { az boards work-item update --id $id --state Done --org $org -o none 2>$null }
        else { az boards work-item delete --id $id --org $org --project $proj --yes -o none 2>$null }
    }
    $mode = if ($CloseWorkItems) { 'Done 처리' } else { '휴지통으로 이동' }
    Add-Result 'ADO 일감' '완료' ("{0}건 {1}" -f $ids.Count, $mode)
}

# 3. ADO PR
Write-Host "`n[3/6] Azure DevOps PR 정리"
$prs = az repos pr list --repository $cfg.adoRepo --status active --org $org --project $proj --query '[].pullRequestId' -o tsv 2>$null
if ($LASTEXITCODE -ne 0) { Add-Result 'ADO PR' '수동' 'Repos > Pull requests 에서 진행 중 PR 을 Abandon 한다' }
else {
    $prIds = @($prs | Where-Object { $_ })
    foreach ($p in $prIds) { az repos pr update --id $p --status abandoned --org $org -o none 2>$null }
    Add-Result 'ADO PR' '완료' ("{0}건 Abandon" -f $prIds.Count)
}

# 4. 레포
Write-Host "`n[4/6] 레포를 baseline 으로 되돌리기"
Push-Location $root
try {
    git fetch --all --tags --prune 2>$null
    git checkout -f main 2>$null
    git reset --hard baseline
    git push --force origin main 2>$null
    $pushOk = ($LASTEXITCODE -eq 0)
    $branches = @(git branch -r --list 'origin/drift/*' | ForEach-Object { $_.Trim() -replace '^origin/', '' })
    foreach ($b in $branches) { git push origin --delete $b 2>$null; git branch -D $b 2>$null }
    git branch --list 'drift/*' | ForEach-Object { git branch -D $_.Trim() 2>$null }
    if ($pushOk) { Add-Result '레포' '완료' ("main = baseline, drift 브랜치 {0}개 삭제" -f $branches.Count) }
    else { Add-Result '레포' '확인' 'force push 거부: 레포 보안 설정에서 본인에게 Force push 허용' }
}
finally { Pop-Location }

# 5. Obsidian 주간 보고서
Write-Host "`n[5/6] Obsidian 주간 보고서 정리"
$weekly = Join-Path $kit 'DevDays-Vault/Reports/Weekly'
$removed = @()
if (Test-Path $weekly) {
    Get-ChildItem $weekly -Filter '*.md' | Where-Object { $_.Name -ne '2026-W40.md' } | ForEach-Object { Remove-Item $_.FullName -Force; $removed += $_.Name }
}
Add-Result 'Obsidian 보고서' '완료' $(if ($removed) { '삭제: ' + ($removed -join ', ') } else { '삭제할 파일 없음' })

# 6. Confluence 안내
Write-Host "`n[6/6] Confluence (수동, 1분)"
$space = if ($cfg.confluenceBaseUrl) { "$($cfg.confluenceBaseUrl.TrimEnd('/'))/wiki/spaces/$($cfg.confluenceSpace)" } else { "스페이스 $($cfg.confluenceSpace)" }
Write-Host "  - $space 에서 상위 페이지 '$($cfg.confluenceParentPage)' 를 연다"
Write-Host "  - 오른쪽 위 ··· > 삭제 > '하위 페이지도 삭제'를 선택한다"
Write-Host "  - 남겨 두면 다음 데모에서는 같은 페이지가 '업데이트'된다 (데모에는 지장 없음)"
Add-Result 'Confluence' '수동' '상위 페이지를 하위 페이지와 함께 삭제 (또는 그대로 두기)'

Write-Host "`n=== 초기화 결과 ==="
$summary | Format-Table -Wrap | Out-String -Width 200 | Write-Host

Write-Host '=== 사전 점검 ==='
& "$PSScriptRoot/preflight.ps1"
Write-Host ''
Write-Host '다시 시작: VS Code 새 채팅(Agent 모드) → DEMO-GUIDE.md "다시 시작하기" 순서대로'
