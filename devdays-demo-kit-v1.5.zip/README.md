# GitHub Copilot Dev Days 데모 키트 v1.5

비개발자·Azure 엔지니어 대상 세션 "코드 한 줄 없이 형상관리를 자동화하는 GitHub Copilot"의 데모 소스이다.
Bicep으로 관리하는 리소스 그룹의 변경을 Copilot이 분석하고, Azure DevOps 일감·PR과 문서,
주간 보고서(Obsidian), 팀·고객 공유 문서(Confluence)까지 처리한다. 변경 내역은 `CHANGELOG.md`를 본다.

## 구성

```
devdays-demo-kit/
├─ CHANGELOG.md                  # 버전별 변경 내역
├─ DEMO-GUIDE.md                 # 발표자 큐시트 + 데모 대본 (실제 리소스 이름 포함)
├─ devdays.code-workspace        # 멀티루트 워크스페이스 + Copilot 자동 승인 규칙
├─ infra/                        # Azure DevOps Repos `infra` 레포
│  ├─ demo.config.json           # 환경 값의 단일 원천 (구독 ID 등)
│  ├─ DEMO-ENV.md                # 실제 리소스 이름 (자동 생성)
│  ├─ .github/
│  │  ├─ copilot-instructions.md     # 항상 적용되는 팀 규칙
│  │  └─ skills/
│  │     ├─ drift-check/                 # /drift-check  (SKILL.md + drift-snapshot.ps1)
│  │     ├─ weekly-report/               # /weekly-report (SKILL.md + weekly-snapshot.ps1, Obsidian)
│  │     └─ confluence-publish/SKILL.md  # /confluence-publish (Confluence)
│  ├─ .vscode/
│  │  ├─ mcp.json                 # Azure DevOps Remote MCP + Microsoft Learn MCP
│  │  └─ copilot-approvals.user-settings.jsonc  # 승인 최소화 규칙 (사용자 설정 붙여넣기용)
│  ├─ bicep/                     # 형상 기준 (VNet, NSG, Storage, Key Vault)
│  ├─ alerting/                  # 실시간 알림 (Event Grid -> Logic App -> Teams), 사전 구축
│  ├─ docs/                      # Copilot이 현행화하는 산출물
│  └─ scripts/                   # switch-env(구독 전환), setup-all(준비), preflight(점검), 00~04, cleanup-env
└─ DevDays-Vault/                # Obsidian Vault (주간 보고서 게시 위치)
```

## 사전 요구사항

| 항목 | 요구사항 |
|---|---|
| Azure | 구독 기여자 권한, 리소스 그룹 2개 생성 가능 |
| Azure DevOps | Microsoft Entra ID에 연결된 조직 (MSA 단독 조직은 Remote MCP 미지원) |
| Teams | 표준 채널 + Workflows 앱 사용 가능 |
| Confluence | Atlassian Cloud 사이트, 데모용 스페이스 쓰기 권한, VS Code에 Atlassian Rovo MCP 서버 연결 |
| 로컬 | VS Code 최신, GitHub Copilot, PowerShell 7, Azure CLI 2.76 이상, Bicep CLI, Git for Windows, Obsidian |
| CLI 확장 | `resource-graph`, `azure-devops` (`setup-all.ps1`이 자동 설치) |

## 환경 값 관리

환경 값은 `infra/demo.config.json` 한 곳에서 관리한다. 스크립트, Skill 수집 스크립트, Copilot 규칙은 모두 이 파일을 기준으로 동작한다.

| 하고 싶은 일 | 명령 (`infra/scripts`에서) |
|---|---|
| 구독 바꾸기 (설정 → 배포 → 이름 반영 → 커밋·baseline → 점검) | `./switch-env.ps1 -SubscriptionId <새 구독 ID>` |
| 이전 구독 정리 | `./cleanup-env.ps1 -SubscriptionId <이전 구독 ID> -PurgeKeyVault` |
| 현재 구독 재준비 (없는 것만 배포) | `./setup-all.ps1` |
| **리허설 후 전체 초기화** (Azure·ADO 일감·PR·레포·Obsidian) + 점검 | `./reset-all.ps1` |
| Azure 리소스만 되돌리기 | `./04-reset-demo.ps1` |
| 점검만 | `./preflight.ps1` |

- 새 구독이 다른 테넌트에 있으면 먼저 `az login --tenant <테넌트 ID>`로 로그인한다.
- 새 구독에서는 리소스 공급자(Network, Storage, KeyVault, Logic, EventGrid)를 자동 등록한다.
- Teams 채널이 바뀌면 `./02-deploy-alerting.ps1 -ResetWebhook`으로 웹후크를 다시 입력한다.

## v1.4에서 업그레이드 (현재 사용 중인 폴더, 약 5분)

VS Code 터미널(PowerShell 7)에서 한 줄씩 실행한다. `$kit`은 현재 키트 폴더다.

```powershell
$kit = "C:\Users\zerobig\GitHubCopilotDevDays\devdays-demo-kit-v1.4"
```
```powershell
Expand-Archive "$HOME\Downloads\devdays-demo-kit-v1.5.zip" -DestinationPath $kit -Force
```
```powershell
Get-ChildItem $kit -Recurse -File | Unblock-File
```
```powershell
cd "$kit\infra\scripts"
```
```powershell
./setup-all.ps1
```

`setup-all`이 `azure-devops` 확장을 설치하고, 압축 해제로 초기화된 환경 정보(실제 리소스 이름)를 다시 채운다. 점검 표의 "작업 트리 깨끗함"이 FAIL인 것은 정상이다. 이어서 커밋하고 기준점을 옮긴다.

```powershell
cd $kit
```
```powershell
git add .
```
```powershell
git commit -m "v1.5: 대본·초기화 자동화"
```
```powershell
git push origin main
```
```powershell
git tag -f -a baseline -m "데모 시작 기준점 v1.5"
```
```powershell
git push -f origin baseline
```
```powershell
cd infra\scripts
```
```powershell
./reset-all.ps1
```

마지막 점검 표가 모두 OK면 끝이다. VS Code에서 **Developer: Reload Window**를 실행한다.

## 리허설 후 초기화와 다시 시작

```powershell
./reset-all.ps1
```

Azure 변경 3건, Azure DevOps 일감·PR, 레포(baseline), Obsidian 주간 보고서를 한 번에 되돌린다. Confluence는 화면에 나오는 1분 수동 절차를 따른다. 다시 시작하는 순서는 `DEMO-GUIDE.md`의 "다시 시작하기"를 본다.

## 발표 당일 환경

| 항목 | 값 |
|---|---|
| Azure 구독 | `3864b016-4594-40ad-a96b-4a08ac96b537` |
| Azure DevOps | `https://dev.azure.com/azure-mvp/` / 프로젝트 `GHCPDevDays-Demo-IaC-Config-Mgmt` / 레포 `infra` |
| Confluence | 스페이스 `2026` (변경 없음) |

### 새 조직 사전 준비 (ADO 웹, 5분)

1. `azure-mvp` 조직에서 프로젝트 `GHCPDevDays-Demo-IaC-Config-Mgmt`를 만든다 (Process: **Basic**).
2. Repos 상단 레포 이름 옆 드롭다운 > **New repository** > 이름 `infra`, **Add a README 체크 해제**.
3. 조직이 Microsoft Entra ID에 연결되어 있는지 확인한다 (Organization settings > Microsoft Entra). 연결되지 않은 조직은 Remote MCP를 쓸 수 없다.

### 전환 (VS Code 터미널, 키트 루트에서)

```powershell
git add .
```
```powershell
git commit -m "v1.4: 발표 환경(azure-mvp, 구독 3864b016)"
```
```powershell
cd infra\scripts
```
```powershell
./switch-env.ps1 -SubscriptionId 3864b016-4594-40ad-a96b-4a08ac96b537 -AdoOrganization azure-mvp
```

`switch-env`가 Git 원격을 새 조직 레포로 바꾸고 첫 푸시와 `baseline` 태그까지 수행한다. 이후 **Developer: Reload Window** → ADO MCP 재인증(`내 Azure DevOps 프로젝트 목록을 보여줘`) → **Chat: Manage Tool Approval**에서 조회 도구 사전 승인을 다시 확인한다.

## 신규 설치 순서

### 1. Azure DevOps 준비

1. 프로젝트 `GHCPDevDays-Demo-IaC-Config-Mgmt`를 만든다 (Basic 프로세스).
2. Repos 상단 레포 이름 옆 드롭다운 > **New repository**로 빈 레포 `infra`를 만든다 (**Add a README 체크 해제**).
3. 키트 폴더를 푸시하고 `baseline` 태그를 만든다.

### 2. 환경 준비

```powershell
cd infra/scripts
./switch-env.ps1 -SubscriptionId <구독 ID>
```

### 3. VS Code (1회)

1. `devdays.code-workspace`를 열고 워크스페이스를 신뢰한다.
2. Copilot Chat을 **Agent** 모드로 열고, 도구 선택기(Configure Tools)에서 **터미널 실행 도구**를 켠다.
3. 명령 팔레트 > **Chat: Manage Tool Approval** > `ado-remote-mcp`와 Atlassian MCP에서 이름에 `get`·`list`·`search`가 들어간 조회 도구만 사전 승인한다. `microsoft-learn`(조회 전용)은 전체를 사전 승인한다. `create`·`update`·`add`·`link` 쓰기 도구는 그대로 둔다 (G1·G2·G3 승인 게이트).
4. `/drift-check` 실행 시 수집 스크립트나 `az` 조회에서 승인 창이 뜨면 `infra/.vscode/copilot-approvals.user-settings.jsonc` 내용을 사용자 설정(**Preferences: Open User Settings (JSON)**)에 붙여넣는다.
5. 채팅에 `/`를 입력해 `drift-check`, `weekly-report`, `confluence-publish`가 보이는지 확인한다.

Confluence MCP가 아직 없다면 사용자 프로필 MCP 설정(**MCP: Open User Configuration**)에 아래를 추가한다. 이미 연결되어 있으면 추가하지 않는다.

```json
"atlassian": {
  "url": "https://mcp.atlassian.com/v1/mcp",
  "type": "http"
}
```

### 4. Obsidian

`DevDays-Vault` 폴더를 Obsidian에서 Vault로 연다. Copilot이 Vault 폴더에 Markdown을 직접 쓰는 방식이며 Obsidian MCP는 사용하지 않는다.

## 데모 진행

`DEMO-GUIDE.md`의 큐시트와 대본을 따른다.

## 설계 메모

- 환경 값은 `demo.config.json` 단일 원천. `update-env-info.ps1`이 실제 이름을 `copilot-instructions.md`(ENV 구간)·`DEMO-ENV.md`·`mcp.json`에 반영한다. 이름을 규칙에 미리 넣어 Copilot의 조회 단계를 없앤다.
- `/drift-check`·`/weekly-report`는 Skill 폴더의 수집 스크립트 1회로 데이터를 모은다. 변경 이력과 what-if를 병렬 실행하고, 원본 JSON 대신 판정에 필요한 항목만 KST 표로 넘겨 응답 시간을 줄인다. Windows `az.cmd`가 여러 줄 인수를 자르는 문제를 피하려고 KQL은 한 줄로 전달한다.
- 승인은 영향 범위 기준 3개 게이트(G1 일감 기록, G2 push·PR, G3 Confluence 게시)로 한정한다. Azure 변경 명령은 자동 승인에서 제외하고 Instructions로 금지한다.
- 시각은 KST로 통일한다 (Logic App `convertFromUtc`, Resource Graph `changeTime + 9h`).
- 알림 Logic App은 Event Grid 구독 검증(validationCode 회신)을 워크플로 안에서 처리하고, 배포 기록 이벤트는 고급 필터로 제외한다. Teams 알림은 Workflows 웹후크를 쓰며, URL은 임시 매개변수 파일로 전달한다.
- Obsidian(개인 지식베이스)과 Confluence(팀·고객 공유)는 같은 원천(`docs/`, 주간 보고서)에서 만든다.
